---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
SLR Repository ^8UxGRumg

SLR-FC ^Tqdu9Tk1

Obsidian ^gWQhUYmv

learn-github ^DZ2fpmhx

https://drshahizan.github.io/ ^wqLdULnX

https://github.com/drshahizan ^T9DsxvsH

Session 1a: Basic ^bFOZVQRP

Session 1b: Advanced ^JN3AIy8d

gitbook.io/copywriting-chatgpt ^GrlDOpuy

gitbook.io/ai-tools ^QUphAum9

Start here ^S4N3YyLd


# Embedded files
376262a7b590928664d58ba10b0206fa36f8e9b1: [[Pasted Image 20240202102119_150.png]]

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/2.0.18",
	"elements": [
		{
			"type": "embeddable",
			"version": 1258,
			"versionNonce": 2137021639,
			"isDeleted": false,
			"id": "cg2_IAyDjrPs8lQrbv9mC",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 748.6644550398283,
			"y": -353.4019224877451,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffec99",
			"width": 236.0809589460785,
			"height": 142.34826899509807,
			"seed": 1300918537,
			"groupIds": [],
			"frameId": "ahP08ndLEcj6uP2poHojg",
			"roundness": null,
			"boundElements": [],
			"updated": 1706840186033,
			"link": "https://drshahizan.github.io/",
			"locked": false,
			"scale": [
				0.25,
				0.25
			]
		},
		{
			"type": "embeddable",
			"version": 902,
			"versionNonce": 1542567111,
			"isDeleted": false,
			"id": "VdRBImHuWR_87E0-YlY17",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 152.5191195618873,
			"y": -339.7578890931373,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffec99",
			"width": 208.76041666666666,
			"height": 125.78906250000003,
			"seed": 1034383049,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [
				{
					"id": "x07v31AhYd0WxIya1irdy",
					"type": "arrow"
				},
				{
					"id": "6jUoJ5LGNECiNYrzrDgL9",
					"type": "arrow"
				},
				{
					"id": "zMJ4HlG6TqgsDQ53M3BlH",
					"type": "arrow"
				}
			],
			"updated": 1706839305271,
			"link": "https://github.com/drshahizan",
			"locked": false,
			"scale": [
				0.25,
				0.25
			]
		},
		{
			"type": "text",
			"version": 745,
			"versionNonce": 334615625,
			"isDeleted": false,
			"id": "8UxGRumg",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -101.92301432291686,
			"y": -510.1383272058824,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 252.10546875,
			"height": 41.4,
			"seed": 244151751,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706840579935,
			"link": null,
			"locked": false,
			"fontSize": 36,
			"fontFamily": 2,
			"text": "SLR Repository",
			"rawText": "SLR Repository",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "SLR Repository",
			"lineHeight": 1.15,
			"baseline": 33
		},
		{
			"type": "embeddable",
			"version": 988,
			"versionNonce": 1610226505,
			"isDeleted": false,
			"id": "kkxMsCTbJsAGrMY1xunYs",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -96.9092658547795,
			"y": -154.60229013480392,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffec99",
			"width": 209.603515625,
			"height": 133.01236979166674,
			"seed": 1980263015,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [
				{
					"id": "x07v31AhYd0WxIya1irdy",
					"type": "arrow"
				},
				{
					"id": "bWPwcf4zd3sXIKXCl9SAc",
					"type": "arrow"
				}
			],
			"updated": 1706840116318,
			"link": "https://github.com/drshahizan/SLR-FC",
			"locked": false,
			"scale": [
				0.25,
				0.25
			]
		},
		{
			"type": "embeddable",
			"version": 1042,
			"versionNonce": 1950351081,
			"isDeleted": false,
			"id": "7QtkntMvIXR_8ebRVMdx1",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 151.85115081188718,
			"y": -156.01374846813724,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffec99",
			"width": 213.66276041666674,
			"height": 130.39518229166669,
			"seed": 1969157161,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [
				{
					"id": "6jUoJ5LGNECiNYrzrDgL9",
					"type": "arrow"
				},
				{
					"id": "O3yp0zRceFPhwQ29MYU-O",
					"type": "arrow"
				},
				{
					"id": "bWPwcf4zd3sXIKXCl9SAc",
					"type": "arrow"
				}
			],
			"updated": 1706840198911,
			"link": "https://github.com/drshahizan/obsidian",
			"locked": false,
			"scale": [
				0.25,
				0.25
			]
		},
		{
			"type": "embeddable",
			"version": 1110,
			"versionNonce": 837500359,
			"isDeleted": false,
			"id": "MdJfH77VsSxQwtRvPEkeH",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 404.049067478554,
			"y": -154.74096200980392,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffec99",
			"width": 212.03515625000003,
			"height": 126.560546875,
			"seed": 794981447,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [
				{
					"id": "6jUoJ5LGNECiNYrzrDgL9",
					"type": "arrow"
				}
			],
			"updated": 1706839305271,
			"link": "https://github.com/drshahizan/learn-github",
			"locked": false,
			"scale": [
				0.25,
				0.25
			]
		},
		{
			"type": "arrow",
			"version": 1583,
			"versionNonce": 1728952327,
			"isDeleted": false,
			"id": "x07v31AhYd0WxIya1irdy",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 254.18662214713257,
			"y": -212.74747242647064,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 220.7424219127752,
			"height": 57.145182291666714,
			"seed": 339135913,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [],
			"updated": 1706839305271,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "VdRBImHuWR_87E0-YlY17",
				"focus": -0.7052526233972719,
				"gap": 1.221354166666643
			},
			"endBinding": {
				"elementId": "kkxMsCTbJsAGrMY1xunYs",
				"focus": -0.6502926028073412,
				"gap": 1
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-220.7424219127752,
					57.145182291666714
				]
			]
		},
		{
			"type": "arrow",
			"version": 1882,
			"versionNonce": 2026315559,
			"isDeleted": false,
			"id": "6jUoJ5LGNECiNYrzrDgL9",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 252.27784600880258,
			"y": -211.75463388480398,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 255.1901699710826,
			"height": 54.26948756876732,
			"seed": 1880105607,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [],
			"updated": 1706839305271,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "VdRBImHuWR_87E0-YlY17",
				"focus": 0.7773005747193366,
				"gap": 2.2141927083333
			},
			"endBinding": {
				"elementId": "MdJfH77VsSxQwtRvPEkeH",
				"focus": 0.7628412230088563,
				"gap": 2.7441843062327393
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					255.1901699710826,
					54.26948756876732
				]
			]
		},
		{
			"type": "text",
			"version": 366,
			"versionNonce": 1493606983,
			"isDeleted": false,
			"id": "Tqdu9Tk1",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -27.701583563112848,
			"y": -14.66999846813718,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 56.22395324707031,
			"height": 20,
			"seed": 339059271,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [
				{
					"id": "aBB7HqedKK6AapXBxP6Xt",
					"type": "arrow"
				}
			],
			"updated": 1706839305271,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "SLR-FC",
			"rawText": "SLR-FC",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "SLR-FC",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "arrow",
			"version": 1145,
			"versionNonce": 955907207,
			"isDeleted": false,
			"id": "O3yp0zRceFPhwQ29MYU-O",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 253.4210901899639,
			"y": -215.651118259804,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 1.7879056151731163,
			"height": 56.115885416666714,
			"seed": 1591477287,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [],
			"updated": 1706839305271,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "7QtkntMvIXR_8ebRVMdx1",
				"focus": -0.011790432551371329,
				"gap": 3.521484375000057
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					1.7879056151731163,
					56.115885416666714
				]
			]
		},
		{
			"type": "arrow",
			"version": 1184,
			"versionNonce": 352181353,
			"isDeleted": false,
			"id": "zMJ4HlG6TqgsDQ53M3BlH",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 252.97165270555595,
			"y": -418.28733915441165,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 0.08723795644382903,
			"height": 47.4174708946079,
			"seed": 399346407,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706840235009,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "T9DsxvsH",
				"focus": -0.17491408732657843,
				"gap": 4.7819010416663446
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0.08723795644382903,
					47.4174708946079
				]
			]
		},
		{
			"type": "text",
			"version": 416,
			"versionNonce": 1035391911,
			"isDeleted": false,
			"id": "gWQhUYmv",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 221.3791481466854,
			"y": -16.748774509803866,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 62.687957763671875,
			"height": 20,
			"seed": 789183431,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [],
			"updated": 1706839305271,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Obsidian",
			"rawText": "Obsidian",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Obsidian",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "text",
			"version": 309,
			"versionNonce": 1057736391,
			"isDeleted": false,
			"id": "DZ2fpmhx",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 462.00089039522055,
			"y": -19.066482843136782,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 90.23992919921875,
			"height": 20,
			"seed": 256817863,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [],
			"updated": 1706839305271,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "learn-github",
			"rawText": "learn-github",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "learn-github",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "text",
			"version": 459,
			"versionNonce": 1625762791,
			"isDeleted": false,
			"id": "wqLdULnX",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 745.7281422334552,
			"y": -186.9565333946078,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 239.19981384277344,
			"height": 20,
			"seed": 1798295815,
			"groupIds": [],
			"frameId": "ahP08ndLEcj6uP2poHojg",
			"roundness": null,
			"boundElements": [],
			"updated": 1706840186033,
			"link": "https://drshahizan.github.io/",
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "🌐https://drshahizan.github.io/",
			"rawText": "https://drshahizan.github.io/",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "🌐https://drshahizan.github.io/",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "text",
			"version": 408,
			"versionNonce": 731207143,
			"isDeleted": false,
			"id": "T9DsxvsH",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 150.17146331188684,
			"y": -366.0879672181374,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 249.47181701660156,
			"height": 20,
			"seed": 1114127241,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [
				{
					"id": "zMJ4HlG6TqgsDQ53M3BlH",
					"type": "arrow"
				}
			],
			"updated": 1706839305271,
			"link": "https://github.com/drshahizan",
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "🌐https://github.com/drshahizan",
			"rawText": "https://github.com/drshahizan",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "🌐https://github.com/drshahizan",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "embeddable",
			"version": 484,
			"versionNonce": 1092266823,
			"isDeleted": false,
			"id": "IJk_vvYyZHLefBMf8v2fz",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -98.81291168811384,
			"y": 48.18937653186265,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 210.1985677083334,
			"height": 192.92643229166683,
			"seed": 481125993,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [
				{
					"id": "aBB7HqedKK6AapXBxP6Xt",
					"type": "arrow"
				},
				{
					"id": "OWQzG-o8Yrr1ahaygg3Ev",
					"type": "arrow"
				}
			],
			"updated": 1706839305271,
			"link": "https://github.com/drshahizan/SLR-FC/blob/main/materials/session1a.md",
			"locked": false,
			"scale": [
				0.2,
				0.2
			]
		},
		{
			"type": "arrow",
			"version": 790,
			"versionNonce": 393968807,
			"isDeleted": false,
			"id": "aBB7HqedKK6AapXBxP6Xt",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -3.269291896446987,
			"y": 6.844975490196077,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 0.791015625,
			"height": 40.680338541666686,
			"seed": 863041737,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [],
			"updated": 1706839305271,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "Tqdu9Tk1",
				"focus": 0.13790473447262974,
				"gap": 1.5149739583332575
			},
			"endBinding": {
				"elementId": "IJk_vvYyZHLefBMf8v2fz",
				"focus": -0.06427709491284302,
				"gap": 1
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0.791015625,
					40.680338541666686
				]
			]
		},
		{
			"type": "embeddable",
			"version": 552,
			"versionNonce": 2026570023,
			"isDeleted": false,
			"id": "ct73SPtnj7G-4foGBkxjb",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 167.38012216605364,
			"y": 47.86483226102928,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 210.1985677083334,
			"height": 189.16341145833354,
			"seed": 591205063,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [],
			"updated": 1706839331877,
			"link": "https://github.com/drshahizan/SLR-FC/blob/main/materials/session1b.md",
			"locked": false,
			"scale": [
				0.2,
				0.2
			]
		},
		{
			"type": "arrow",
			"version": 515,
			"versionNonce": 2030288615,
			"isDeleted": false,
			"id": "OWQzG-o8Yrr1ahaygg3Ev",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 111.78279143688712,
			"y": 142.5285692401959,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 56.68294270833337,
			"height": 0.7259114583333712,
			"seed": 1486825065,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [],
			"updated": 1706839305271,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "IJk_vvYyZHLefBMf8v2fz",
				"focus": -0.007902950265337518,
				"gap": 1
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					56.68294270833337,
					-0.7259114583333712
				]
			]
		},
		{
			"type": "text",
			"version": 473,
			"versionNonce": 806963719,
			"isDeleted": false,
			"id": "bFOZVQRP",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -59.704836228314775,
			"y": 244.5988817401959,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 133.1039276123047,
			"height": 20,
			"seed": 1599856615,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [],
			"updated": 1706839305271,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Session 1a: Basic",
			"rawText": "Session 1a: Basic",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Session 1a: Basic",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "text",
			"version": 569,
			"versionNonce": 427054471,
			"isDeleted": false,
			"id": "JN3AIy8d",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 194.6123380474018,
			"y": 245.24927236519568,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 160.0319061279297,
			"height": 20,
			"seed": 1009134025,
			"groupIds": [],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [],
			"updated": 1706839324519,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Session 1b: Advanced",
			"rawText": "Session 1b: Advanced",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Session 1b: Advanced",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "rectangle",
			"version": 3362,
			"versionNonce": 1328526439,
			"isDeleted": false,
			"id": "RPJyJHWH7HmfTG7FXvm3F",
			"fillStyle": "cross-hatch",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -87.13413584853333,
			"y": -358.43053743595345,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 64.46115236495699,
			"height": 64.39942473426015,
			"seed": 221225,
			"groupIds": [
				"yCHThEd887G6SLIe9_u_3",
				"DNsGDqd3lqVFd9ziCYY5k",
				"uImqGSkwsEsGzxvyu7XTa",
				"VKZF8kQJLC4eUoflGK38O",
				"aAVTu2YgNEPWa-mToWxS0"
			],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [],
			"updated": 1706839519603,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1317,
			"versionNonce": 1143040393,
			"isDeleted": false,
			"id": "jK8mTqHP3QNldwFdmilwQ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -80.84481105021496,
			"y": -352.05830907264834,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 51.88250276832002,
			"height": 51.88250276832002,
			"seed": 651653897,
			"groupIds": [
				"MLmZOmj52CU-2FzhB68e8",
				"aAVTu2YgNEPWa-mToWxS0"
			],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": null,
			"boundElements": [],
			"updated": 1706839519603,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 4863,
			"versionNonce": 405442439,
			"isDeleted": false,
			"id": "sdmisuQWkWtHKWpeKJF4q",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -65.09704711952872,
			"y": -341.65025846309,
			"strokeColor": "#000000",
			"backgroundColor": "#fff",
			"width": 28.10264153823924,
			"height": 32.45750960039449,
			"seed": 1130768873,
			"groupIds": [
				"MLmZOmj52CU-2FzhB68e8",
				"aAVTu2YgNEPWa-mToWxS0"
			],
			"frameId": "0xnnIBS7IQh3mTUclJKT0",
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706839519603,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.522383435627326,
					0.8876695614221044
				],
				[
					4.222250533550099,
					2.710891079770457
				],
				[
					6.53876438289814,
					1.9494891881139838
				],
				[
					13.00273268947289,
					2.0374391115495714
				],
				[
					15.018859724261578,
					2.2364052653721083
				],
				[
					16.578273739956423,
					0.9941438562971401
				],
				[
					18.744233429245106,
					-0.5092823311506232
				],
				[
					19.3382730064762,
					1.5588921397895759
				],
				[
					19.283438583962543,
					3.566556278350808
				],
				[
					21.26661686487244,
					5.46749782452002
				],
				[
					22.153106695509578,
					10.909367329014938
				],
				[
					21.45853734367018,
					16.608727547781946
				],
				[
					19.438802781084537,
					18.8230883820351
				],
				[
					16.687942584983702,
					20.009258415382803
				],
				[
					13.71774469882833,
					20.664602961087855
				],
				[
					14.50370475485716,
					21.40308436092641
				],
				[
					15.390194585494283,
					23.040424434305827
				],
				[
					15.572975993873055,
					28.176226896819482
				],
				[
					15.536419712197318,
					31.28569415677526
				],
				[
					14.567678247789736,
					31.823854903738514
				],
				[
					7.240428539404906,
					31.948227269243866
				],
				[
					6.324236729906197,
					31.05132655929166
				],
				[
					6.068342758175913,
					27.392989048505843
				],
				[
					4.377614730672068,
					27.862931757494
				],
				[
					1.5810591824765403,
					28.041957551394276
				],
				[
					-1.0327149573401755,
					26.542616527479623
				],
				[
					-2.659469491911409,
					23.92436429168835
				],
				[
					-4.240528674387946,
					22.313132146586064
				],
				[
					-5.949534842729662,
					21.179302118551103
				],
				[
					-3.628210956319009,
					21.40308436092641
				],
				[
					-1.9831782809098755,
					22.671183734386556
				],
				[
					-0.11880791544621871,
					24.43906344915162
				],
				[
					2.147681548450816,
					25.543055844869823
				],
				[
					4.660925913659192,
					25.22976070554441
				],
				[
					5.9038394906349865,
					24.252578247172192
				],
				[
					6.022647406081191,
					22.71594018286161
				],
				[
					6.689799546663803,
					21.380706136688904
				],
				[
					7.558011236463052,
					20.776494082275484
				],
				[
					4.277084956063728,
					19.93358096932851
				],
				[
					1.1423838023674477,
					18.89984919335192
				],
				[
					-0.4569535209469784,
					16.571430507386058
				],
				[
					-1.6541717458280658,
					10.963038997107194
				],
				[
					-0.7037084222583516,
					5.6861115380996985
				],
				[
					0.6671521405825978,
					4.240069736001822
				],
				[
					-0.11880791544621871,
					2.2772861946741387
				],
				[
					0,
					0
				]
			]
		},
		{
			"id": "0xnnIBS7IQh3mTUclJKT0",
			"type": "frame",
			"x": -108.2396790747548,
			"y": -371.0709826899505,
			"width": 743.7637867647057,
			"height": 657.3851102941176,
			"angle": 0,
			"strokeColor": "#bbb",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 488459689,
			"version": 337,
			"versionNonce": 1227723175,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "I83eF9Wpu7txVC0XMNwiO",
					"type": "arrow"
				},
				{
					"id": "bWPwcf4zd3sXIKXCl9SAc",
					"type": "arrow"
				},
				{
					"id": "ffnV3qK24VeXsAwRtm4jD",
					"type": "arrow"
				}
			],
			"updated": 1706840566029,
			"link": null,
			"locked": false,
			"customData": {
				"frameColor": {
					"stroke": "#D4D4D4",
					"fill": "#ADADAD",
					"nameColor": "#949494"
				}
			},
			"name": "Github"
		},
		{
			"id": "2Y9bPeEodZcnzOa5tVGxV",
			"type": "embeddable",
			"x": 749.0020488664215,
			"y": -108.73182827818567,
			"width": 241.56709558823525,
			"height": 138.9981617647058,
			"angle": 0,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": "iR-1_G821tCU3puV2-bZj",
			"roundness": null,
			"seed": 902966375,
			"version": 600,
			"versionNonce": 711827977,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "bWPwcf4zd3sXIKXCl9SAc",
					"type": "arrow"
				}
			],
			"updated": 1706840410048,
			"link": "https://drshahizan.gitbook.io/copywriting-chatgpt/",
			"locked": false,
			"scale": [
				0.2,
				0.2
			]
		},
		{
			"id": "GrlDOpuy",
			"type": "text",
			"x": 757.604990042892,
			"y": 44.4837048100494,
			"width": 226.57582092285156,
			"height": 20,
			"angle": 0,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": "iR-1_G821tCU3puV2-bZj",
			"roundness": null,
			"seed": 2047716007,
			"version": 700,
			"versionNonce": 909909767,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1706840410048,
			"link": "https://drshahizan.gitbook.io/copywriting-chatgpt/",
			"locked": false,
			"text": "gitbook.io/copywriting-chatgpt",
			"rawText": "gitbook.io/copywriting-chatgpt",
			"fontSize": 16,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 14,
			"containerId": null,
			"originalText": "gitbook.io/copywriting-chatgpt",
			"lineHeight": 1.25
		},
		{
			"type": "embeddable",
			"version": 767,
			"versionNonce": 1918793961,
			"isDeleted": false,
			"id": "o7UXMVzxaPcu8OU0jMRVA",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1021.1118834252445,
			"y": -106.31454886641947,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 241.56709558823525,
			"height": 138.9981617647058,
			"seed": 2003445767,
			"groupIds": [],
			"frameId": "iR-1_G821tCU3puV2-bZj",
			"roundness": null,
			"boundElements": [],
			"updated": 1706840410048,
			"link": "https://drshahizan.gitbook.io/ai-tools/",
			"locked": false,
			"scale": [
				0.2,
				0.2
			]
		},
		{
			"type": "text",
			"version": 927,
			"versionNonce": 1133553191,
			"isDeleted": false,
			"id": "QUphAum9",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 1023.7178148755836,
			"y": 47.88214231005088,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 139.3759002685547,
			"height": 20,
			"seed": 1921288745,
			"groupIds": [],
			"frameId": "iR-1_G821tCU3puV2-bZj",
			"roundness": null,
			"boundElements": [],
			"updated": 1706840410048,
			"link": "https://drshahizan.gitbook.io/ai-tools/",
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "gitbook.io/ai-tools",
			"rawText": "gitbook.io/ai-tools",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "gitbook.io/ai-tools",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"id": "ahP08ndLEcj6uP2poHojg",
			"type": "frame",
			"x": 734.7998429840677,
			"y": -371.0388135723018,
			"width": 266.0983455882352,
			"height": 216.875,
			"angle": 0,
			"strokeColor": "#bbb",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 156437895,
			"version": 398,
			"versionNonce": 50796295,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "I83eF9Wpu7txVC0XMNwiO",
					"type": "arrow"
				}
			],
			"updated": 1706840186033,
			"link": null,
			"locked": false,
			"customData": {
				"frameColor": {
					"stroke": "#D4D4D4",
					"fill": "#ADADAD",
					"nameColor": "#949494"
				}
			},
			"name": "Github.io"
		},
		{
			"id": "iR-1_G821tCU3puV2-bZj",
			"type": "frame",
			"x": 732.4744753370087,
			"y": -123.01491651347806,
			"width": 546.9669117647061,
			"height": 205.04595588235298,
			"angle": 0,
			"strokeColor": "#bbb",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 471514793,
			"version": 694,
			"versionNonce": 16190377,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "bWPwcf4zd3sXIKXCl9SAc",
					"type": "arrow"
				},
				{
					"id": "I83eF9Wpu7txVC0XMNwiO",
					"type": "arrow"
				}
			],
			"updated": 1706840410042,
			"link": null,
			"locked": false,
			"customData": {
				"frameColor": {
					"stroke": "#D4D4D4",
					"fill": "#ADADAD",
					"nameColor": "#949494"
				}
			},
			"name": "Gitbook"
		},
		{
			"id": "I83eF9Wpu7txVC0XMNwiO",
			"type": "arrow",
			"x": 731.8752106311265,
			"y": -267.8575449894456,
			"width": 93.92003676470404,
			"height": 0,
			"angle": 0,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 1702899751,
			"version": 670,
			"versionNonce": 2068620359,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1706840194607,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-93.92003676470404,
					0
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "ahP08ndLEcj6uP2poHojg",
				"focus": 0.04847245110910704,
				"gap": 2.9246323529412166
			},
			"endBinding": {
				"elementId": "0xnnIBS7IQh3mTUclJKT0",
				"focus": -0.6859879054628218,
				"gap": 2.431066176471518
			},
			"startArrowhead": "arrow",
			"endArrowhead": "arrow"
		},
		{
			"type": "arrow",
			"version": 1217,
			"versionNonce": 1693710441,
			"isDeleted": false,
			"id": "bWPwcf4zd3sXIKXCl9SAc",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 729.3605047487735,
			"y": -82.49204534865198,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 91.50183823529437,
			"height": 0.490726653363069,
			"seed": 138156169,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706840570087,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "iR-1_G821tCU3puV2-bZj",
				"focus": 0.5819491879835096,
				"gap": 3.1139705882352473
			},
			"endBinding": {
				"elementId": "0xnnIBS7IQh3mTUclJKT0",
				"focus": -0.1288568371943967,
				"gap": 2.334558823528141
			},
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-91.50183823529437,
					-0.490726653363069
				]
			]
		},
		{
			"id": "3xpMM-nTJye1SEjhXAsT1",
			"type": "rectangle",
			"x": 183.17024739583172,
			"y": -454.1776003370083,
			"width": 138.18474264705884,
			"height": 36.640625,
			"angle": 0,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffec99",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 607452039,
			"version": 125,
			"versionNonce": 606439815,
			"isDeleted": false,
			"boundElements": [
				{
					"type": "text",
					"id": "S4N3YyLd"
				}
			],
			"updated": 1706840244020,
			"link": null,
			"locked": false
		},
		{
			"id": "S4N3YyLd",
			"type": "text",
			"x": 209.43864410998614,
			"y": -445.8572878370083,
			"width": 85.64794921875,
			"height": 20,
			"angle": 0,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 820284999,
			"version": 106,
			"versionNonce": 763489895,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1706840242775,
			"link": null,
			"locked": false,
			"text": "Start here",
			"rawText": "Start here",
			"fontSize": 16,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 14,
			"containerId": "3xpMM-nTJye1SEjhXAsT1",
			"originalText": "Start here",
			"lineHeight": 1.25
		},
		{
			"id": "Z9Z6Dn8BjoRTDT2WKPidg",
			"type": "image",
			"x": 754.9466817371753,
			"y": 118.83618642769807,
			"width": 169.98205778790376,
			"height": 161.99632352941165,
			"angle": 0,
			"strokeColor": "transparent",
			"backgroundColor": "#ffec99",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": "puj8yYZUdsOS_QWs7jNNV",
			"roundness": null,
			"seed": 558988743,
			"version": 315,
			"versionNonce": 2115074535,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1706840543740,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "376262a7b590928664d58ba10b0206fa36f8e9b1",
			"scale": [
				1,
				1
			]
		},
		{
			"id": "puj8yYZUdsOS_QWs7jNNV",
			"type": "frame",
			"x": 737.0176738664212,
			"y": 112.64684819240392,
			"width": 241.45680147058806,
			"height": 174.4439338235294,
			"angle": 0,
			"strokeColor": "#bbb",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 1242325767,
			"version": 206,
			"versionNonce": 1209466727,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "ffnV3qK24VeXsAwRtm4jD",
					"type": "arrow"
				}
			],
			"updated": 1706840566029,
			"link": null,
			"locked": false,
			"customData": {
				"frameColor": {
					"stroke": "#D4D4D4",
					"fill": "#ADADAD",
					"nameColor": "#949494"
				}
			},
			"name": "OneDrive"
		},
		{
			"type": "arrow",
			"version": 1161,
			"versionNonce": 1203367817,
			"isDeleted": false,
			"id": "hCG3aLKRb7jQJ-jkgsLC6",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 772.0608723958333,
			"y": 473.8572850484976,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 91.50183823529437,
			"height": 0.490726653363069,
			"seed": 882757223,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706840550463,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-91.50183823529437,
					-0.490726653363069
				]
			]
		},
		{
			"type": "arrow",
			"version": 1215,
			"versionNonce": 737180295,
			"isDeleted": false,
			"id": "ffnV3qK24VeXsAwRtm4jD",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": 729.7814606311272,
			"y": 163.15416004849766,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 91.50183823529437,
			"height": 0.490726653363069,
			"seed": 1098871399,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706840566029,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "puj8yYZUdsOS_QWs7jNNV",
				"focus": 0.41002172219323785,
				"gap": 7.236213235294031
			},
			"endBinding": {
				"elementId": "0xnnIBS7IQh3mTUclJKT0",
				"focus": 0.61397240091558,
				"gap": 2.7555147058818648
			},
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-91.50183823529437,
					-0.490726653363069
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#1e1e1e",
		"currentItemBackgroundColor": "#ffec99",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 0.5,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 0,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 16,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": "arrow",
		"currentItemEndArrowhead": "arrow",
		"scrollX": 163.69004672181407,
		"scrollY": 601.3696959252418,
		"zoom": {
			"value": 0.8500000000000001
		},
		"currentItemRoundness": "sharp",
		"gridSize": null,
		"gridColor": {
			"Bold": "#C9C9C9FF",
			"Regular": "#EDEDEDFF"
		},
		"currentStrokeOptions": null,
		"previousGridSize": null,
		"frameRendering": {
			"enabled": true,
			"clip": true,
			"name": true,
			"outline": true
		}
	},
	"files": {}
}
```
%%