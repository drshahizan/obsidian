---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
1. Select a topic to write about ^AamVZHgp

2. Identify your target audience ^KpgxlHO1

3. Research facts that reinforce your story ^NF5w6nqt

4. Do you have enough sources? ^UZ0TPnYf

5. Come up with an outline of your article ^HfCBHAKF

6. Find more sources or change your topic ^07l7FhKs

7. Write a rough draft and pare down your outline ^7OVlYkCz

8. Is your draft clear and concise? ^FvsWEqqw

9. Specify your subject matter ^JQsH4sSS

10. Revise your draft and simplify your outline ^G0kgD2Kn

11. Read aloud until your draft is error-free ^sxO59QMO

12. Publish your article ^X0Z1Ht8I

Yes ^mWt8VuUN

No ^FHVE7NRj

Yes ^YdhtxsRK

No ^9W9EViJw

How to Write Effective Articles: A Step-by-Step Guide ^qiCKmJXU

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/2.0.18",
	"elements": [
		{
			"type": "rectangle",
			"version": 4,
			"versionNonce": 332565159,
			"isDeleted": false,
			"id": "uSCrtB1twIBtnZPY4PBM3",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -68.42849392361404,
			"y": -996.0234375000003,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#16C5B7",
			"width": 367.7109375,
			"height": 47.5,
			"seed": 782863465,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "AamVZHgp"
				},
				{
					"id": "odsErYGWxp5wWipuGNL97",
					"type": "arrow"
				}
			],
			"updated": 1706778724102,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 5,
			"versionNonce": 1721277895,
			"isDeleted": false,
			"id": "YmLMN8yvpd69JZ4GrZTCr",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -71.24880642361404,
			"y": -898.5234375000003,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#FFC0CB",
			"width": 373.3515625,
			"height": 47.5,
			"seed": 812521289,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "KpgxlHO1"
				},
				{
					"id": "odsErYGWxp5wWipuGNL97",
					"type": "arrow"
				},
				{
					"id": "-oigS97tUYnEzi5g6LlD3",
					"type": "arrow"
				}
			],
			"updated": 1706778724102,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 5,
			"versionNonce": 426724583,
			"isDeleted": false,
			"id": "9XpZj3dnCTOxUGt6LQ-31",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -129.99490017361404,
			"y": -801.0234375000003,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#FFFF00",
			"width": 490.84375,
			"height": 47.5,
			"seed": 1662928425,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "NF5w6nqt"
				},
				{
					"id": "-oigS97tUYnEzi5g6LlD3",
					"type": "arrow"
				},
				{
					"id": "wKgLLGxbG6tZKFElTM1rQ",
					"type": "arrow"
				}
			],
			"updated": 1706778724102,
			"link": null,
			"locked": false
		},
		{
			"type": "diamond",
			"version": 7,
			"versionNonce": 1482175911,
			"isDeleted": false,
			"id": "Xo1XaINq-t7vLAxWrCP23",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -92.61208767361404,
			"y": -703.5234375000003,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#b2f2bb",
			"width": 416.078125,
			"height": 416.078125,
			"seed": 1906678025,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "UZ0TPnYf"
				},
				{
					"id": "wKgLLGxbG6tZKFElTM1rQ",
					"type": "arrow"
				},
				{
					"id": "Rlk-8JbpglvlL1HL_fN-1",
					"type": "arrow"
				},
				{
					"id": "PBQhOj8IeoprQsbe2-5qG",
					"type": "arrow"
				}
			],
			"updated": 1706778925403,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 5,
			"versionNonce": 670072615,
			"isDeleted": false,
			"id": "4E_SzrOL6QNjp9Xmxx1ne",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -397.05740017361404,
			"y": -204.94531250000034,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#00FF00",
			"width": 487.828125,
			"height": 47.5,
			"seed": 494899177,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "HfCBHAKF"
				},
				{
					"id": "Rlk-8JbpglvlL1HL_fN-1",
					"type": "arrow"
				},
				{
					"id": "nT9ACT3XaFHBcDb_TLpAt",
					"type": "arrow"
				}
			],
			"updated": 1706778724102,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 4,
			"versionNonce": 470024775,
			"isDeleted": false,
			"id": "rzUHvKjuB9NdBTR-uZIC3",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 140.77072482638596,
			"y": -204.94531250000034,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#FFA500",
			"width": 486.453125,
			"height": 47.5,
			"seed": 1823976137,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "07l7FhKs"
				},
				{
					"id": "PBQhOj8IeoprQsbe2-5qG",
					"type": "arrow"
				}
			],
			"updated": 1706778724102,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 6,
			"versionNonce": 871774185,
			"isDeleted": false,
			"id": "_FNB2vcRTwqaikT5aoXvQ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -441.26052517361404,
			"y": -107.44531250000034,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffec99",
			"width": 576.234375,
			"height": 47.5,
			"seed": 401172905,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "7OVlYkCz"
				},
				{
					"id": "nT9ACT3XaFHBcDb_TLpAt",
					"type": "arrow"
				},
				{
					"id": "t4Gspt99RArUOgN8_cELF",
					"type": "arrow"
				}
			],
			"updated": 1706778814054,
			"link": null,
			"locked": false
		},
		{
			"type": "diamond",
			"version": 7,
			"versionNonce": 785781161,
			"isDeleted": false,
			"id": "xFPaJVFoEt9LCEA_lVySl",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -373.62771267361404,
			"y": -9.945312500000341,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#b2f2bb",
			"width": 440.96875,
			"height": 440.96875,
			"seed": 943737993,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "FvsWEqqw"
				},
				{
					"id": "t4Gspt99RArUOgN8_cELF",
					"type": "arrow"
				},
				{
					"id": "GudosHJqhTWmMl8uRI200",
					"type": "arrow"
				},
				{
					"id": "groz-5B_lAsswaGpW1lsR",
					"type": "arrow"
				}
			],
			"updated": 1706778818909,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 5,
			"versionNonce": 1563440039,
			"isDeleted": false,
			"id": "A7lz4_X6cv1Jl3UGa8Ur9",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -579.723415798614,
			"y": 513.5234374999997,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#00FFFF",
			"width": 357.0703125,
			"height": 47.5,
			"seed": 897045353,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "JQsH4sSS"
				},
				{
					"id": "GudosHJqhTWmMl8uRI200",
					"type": "arrow"
				},
				{
					"id": "nqMu9DCncYrqfsSDWQ3OF",
					"type": "arrow"
				}
			],
			"updated": 1706778724102,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 4,
			"versionNonce": 1750673095,
			"isDeleted": false,
			"id": "0gqAbQA--ZTQ9ixTshSSl",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -172.65310329861404,
			"y": 513.5234374999997,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#FF00FF",
			"width": 535.109375,
			"height": 47.5,
			"seed": 1943764553,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "G0kgD2Kn"
				},
				{
					"id": "groz-5B_lAsswaGpW1lsR",
					"type": "arrow"
				}
			],
			"updated": 1706778724102,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 5,
			"versionNonce": 70694375,
			"isDeleted": false,
			"id": "SFb3-c3W6TlFl9I0LC5lq",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -653.446072048614,
			"y": 611.0234374999997,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#FFFFFF",
			"width": 504.515625,
			"height": 47.5,
			"seed": 1111936297,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "sxO59QMO"
				},
				{
					"id": "nqMu9DCncYrqfsSDWQ3OF",
					"type": "arrow"
				},
				{
					"id": "eLWXnczZ2flZ8oRCMcNQI",
					"type": "arrow"
				}
			],
			"updated": 1706778724102,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 4,
			"versionNonce": 1742037255,
			"isDeleted": false,
			"id": "j1jCP-Suzj76uDQOENxJK",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -538.793728298614,
			"y": 708.5234374999997,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#808080",
			"width": 275.2109375,
			"height": 47.5,
			"seed": 136658953,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "X0Z1Ht8I"
				},
				{
					"id": "eLWXnczZ2flZ8oRCMcNQI",
					"type": "arrow"
				}
			],
			"updated": 1706778724102,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 13,
			"versionNonce": 1766646599,
			"isDeleted": false,
			"id": "odsErYGWxp5wWipuGNL97",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 115.426927951386,
			"y": -947.5234375000003,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 43.69999999999993,
			"seed": 863131369,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706778868943,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "uSCrtB1twIBtnZPY4PBM3",
				"gap": 1,
				"focus": 2.549557011896404e-7
			},
			"endBinding": {
				"elementId": "YmLMN8yvpd69JZ4GrZTCr",
				"gap": 5.299999999999997,
				"focus": -2.511038102469774e-7
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0,
					43.69999999999993
				]
			]
		},
		{
			"type": "arrow",
			"version": 13,
			"versionNonce": 1839826887,
			"isDeleted": false,
			"id": "-oigS97tUYnEzi5g6LlD3",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 115.426927951386,
			"y": -850.0234375000003,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 43.69999999999993,
			"seed": 1723437513,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706778868943,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "YmLMN8yvpd69JZ4GrZTCr",
				"gap": 1,
				"focus": 2.5110381024697747e-7
			},
			"endBinding": {
				"elementId": "9XpZj3dnCTOxUGt6LQ-31",
				"gap": 5.300000000000011,
				"focus": -1.909976441696824e-7
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0,
					43.69999999999993
				]
			]
		},
		{
			"type": "arrow",
			"version": 13,
			"versionNonce": 1716513863,
			"isDeleted": false,
			"id": "wKgLLGxbG6tZKFElTM1rQ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 115.43129053854605,
			"y": -752.5234375000003,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 0.39807012167902656,
			"height": 45.348718769226366,
			"seed": 1729523881,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706778868943,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "9XpZj3dnCTOxUGt6LQ-31",
				"gap": 1,
				"focus": 0.0008472806211924762
			},
			"endBinding": {
				"elementId": "Xo1XaINq-t7vLAxWrCP23",
				"gap": 3.673386582633725,
				"focus": 0.010866225288756045
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0.39807012167902656,
					45.348718769226366
				]
			]
		},
		{
			"type": "arrow",
			"version": 9,
			"versionNonce": 1447845287,
			"isDeleted": false,
			"id": "Rlk-8JbpglvlL1HL_fN-1",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 7.299169428413222,
			"y": -394.1589043356,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 160.44224147702727,
			"height": 183.9134668355997,
			"seed": 1244951433,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "mWt8VuUN"
				}
			],
			"updated": 1706778868944,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "Xo1XaINq-t7vLAxWrCP23",
				"gap": 1,
				"focus": -0.007727207299340559
			},
			"endBinding": {
				"elementId": "4E_SzrOL6QNjp9Xmxx1ne",
				"gap": 5.30012499999998,
				"focus": 0.00000108901060182732
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-160.44224147702727,
					147.96346683559966
				],
				[
					-160.44224147702727,
					183.9134668355997
				]
			]
		},
		{
			"type": "arrow",
			"version": 9,
			"versionNonce": 1722403591,
			"isDeleted": false,
			"id": "PBQhOj8IeoprQsbe2-5qG",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 224.03386037346857,
			"y": -394.63798448470993,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 159.96306757791737,
			"height": 184.3925469847096,
			"seed": 1682905705,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "FHVE7NRj"
				}
			],
			"updated": 1706778868944,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "Xo1XaINq-t7vLAxWrCP23",
				"gap": 1,
				"focus": 0.00029494270034784024
			},
			"endBinding": {
				"elementId": "rzUHvKjuB9NdBTR-uZIC3",
				"gap": 5.30012499999998,
				"focus": -0.0000014775318794236174
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					159.96306757791737,
					148.44254698470957
				],
				[
					159.96306757791737,
					184.3925469847096
				]
			]
		},
		{
			"type": "arrow",
			"version": 13,
			"versionNonce": 1492776263,
			"isDeleted": false,
			"id": "nT9ACT3XaFHBcDb_TLpAt",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -153.14307204861404,
			"y": -156.44531250000034,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 43.69987500000002,
			"seed": 1982981449,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706778868944,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "4E_SzrOL6QNjp9Xmxx1ne",
				"gap": 1,
				"focus": -0.0000010890106018273198
			},
			"endBinding": {
				"elementId": "_FNB2vcRTwqaikT5aoXvQ",
				"gap": 5.30012499999998,
				"focus": 9.21933891907339e-7
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0,
					43.69987500000002
				]
			]
		},
		{
			"type": "arrow",
			"version": 13,
			"versionNonce": 2101189063,
			"isDeleted": false,
			"id": "t4Gspt99RArUOgN8_cELF",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -153.13884169969683,
			"y": -58.94531250000034,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 0.39805414987924337,
			"height": 45.34842564487582,
			"seed": 456676393,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706778868944,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "_FNB2vcRTwqaikT5aoXvQ",
				"gap": 1,
				"focus": 0.0007207273450638857
			},
			"endBinding": {
				"elementId": "xFPaJVFoEt9LCEA_lVySl",
				"gap": 3.6736959418505535,
				"focus": 0.01074881001726215
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0.39805414987924337,
					45.34842564487582
				]
			]
		},
		{
			"type": "arrow",
			"version": 9,
			"versionNonce": 308738855,
			"isDeleted": false,
			"id": "GudosHJqhTWmMl8uRI200",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -260.6157024278839,
			"y": 324.9652863081029,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 140.57236962073014,
			"height": 183.2582761918968,
			"seed": 2001594121,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "YdhtxsRK"
				}
			],
			"updated": 1706778868944,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "xFPaJVFoEt9LCEA_lVySl",
				"gap": 1,
				"focus": -0.007807976995315804
			},
			"endBinding": {
				"elementId": "A7lz4_X6cv1Jl3UGa8Ur9",
				"gap": 5.299874999999929,
				"focus": 0.0000010502133246363184
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-140.57236962073014,
					147.30827619189677
				],
				[
					-140.57236962073011,
					183.2582761918968
				]
			]
		},
		{
			"type": "arrow",
			"version": 9,
			"versionNonce": 299325575,
			"isDeleted": false,
			"id": "groz-5B_lAsswaGpW1lsR",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -45.15973644909012,
			"y": 324.4540498378488,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 140.06166440047605,
			"height": 183.76951266215093,
			"seed": 619585001,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "9W9EViJw"
				}
			],
			"updated": 1706778868944,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "xFPaJVFoEt9LCEA_lVySl",
				"gap": 1,
				"focus": -0.00021356789077302065
			},
			"endBinding": {
				"elementId": "0gqAbQA--ZTQ9ixTshSSl",
				"gap": 5.299874999999929,
				"focus": 0.000001284784068514383
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					140.06166440047605,
					147.81951266215088
				],
				[
					140.06166440047605,
					183.76951266215093
				]
			]
		},
		{
			"type": "arrow",
			"version": 13,
			"versionNonce": 222438087,
			"isDeleted": false,
			"id": "nqMu9DCncYrqfsSDWQ3OF",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -401.188072048614,
			"y": 562.0234374999997,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 43.70012500000007,
			"seed": 1663334601,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706778868944,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "A7lz4_X6cv1Jl3UGa8Ur9",
				"gap": 1,
				"focus": -0.0000010502133246363182
			},
			"endBinding": {
				"elementId": "SFb3-c3W6TlFl9I0LC5lq",
				"gap": 5.299874999999929,
				"focus": 7.432871876258621e-7
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0,
					43.70012500000007
				]
			]
		},
		{
			"type": "arrow",
			"version": 13,
			"versionNonce": 1128466247,
			"isDeleted": false,
			"id": "eLWXnczZ2flZ8oRCMcNQI",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -401.188072048614,
			"y": 659.5234374999997,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 43.70012500000007,
			"seed": 59537321,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706778868944,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "SFb3-c3W6TlFl9I0LC5lq",
				"gap": 1,
				"focus": -7.432871876258621e-7
			},
			"endBinding": {
				"elementId": "j1jCP-Suzj76uDQOENxJK",
				"gap": 5.299874999999929,
				"focus": 0.0000013625911943254583
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0,
					43.70012500000007
				]
			]
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 51506823,
			"isDeleted": false,
			"id": "AamVZHgp",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -43.85290188259842,
			"y": -984.7734375000003,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 318.55975341796875,
			"height": 25,
			"seed": 408001161,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724102,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "1. Select a topic to write about",
			"rawText": "1. Select a topic to write about",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "uSCrtB1twIBtnZPY4PBM3",
			"originalText": "1. Select a topic to write about",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 604013991,
			"isDeleted": false,
			"id": "KpgxlHO1",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -46.92287868923904,
			"y": -887.2734375000003,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 324.69970703125,
			"height": 25,
			"seed": 1647272297,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724102,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "2. Identify your target audience",
			"rawText": "2. Identify your target audience",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "YmLMN8yvpd69JZ4GrZTCr",
			"originalText": "2. Identify your target audience",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 1431255239,
			"isDeleted": false,
			"id": "NF5w6nqt",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -106.38283962673904,
			"y": -789.7734375000003,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 443.61962890625,
			"height": 25,
			"seed": 2121354313,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724102,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "3. Research facts that reinforce your story",
			"rawText": "3. Research facts that reinforce your story",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "9XpZj3dnCTOxUGt6LQ-31",
			"originalText": "3. Research facts that reinforce your story",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 1285195751,
			"isDeleted": false,
			"id": "UZ0TPnYf",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 37.567523532440646,
			"y": -520.5039062500003,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 155.67984008789062,
			"height": 50,
			"seed": 1425201961,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724102,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "4. Do you have\nenough sources?",
			"rawText": "4. Do you have enough sources?",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "Xo1XaINq-t7vLAxWrCP23",
			"originalText": "4. Do you have enough sources?",
			"lineHeight": 1.25,
			"baseline": 43
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 1475277575,
			"isDeleted": false,
			"id": "HfCBHAKF",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -361.0331692165828,
			"y": -193.69531250000034,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 415.7796630859375,
			"height": 25,
			"seed": 1176473097,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724102,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "5. Come up with an outline of your article",
			"rawText": "5. Come up with an outline of your article",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "4E_SzrOL6QNjp9Xmxx1ne",
			"originalText": "5. Come up with an outline of your article",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 1338571303,
			"isDeleted": false,
			"id": "07l7FhKs",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 177.89746432833908,
			"y": -193.69531250000034,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 412.19964599609375,
			"height": 25,
			"seed": 418571497,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724102,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "6. Find more sources or change your topic",
			"rawText": "6. Find more sources or change your topic",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "rzUHvKjuB9NdBTR-uZIC3",
			"originalText": "6. Find more sources or change your topic",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 1226120519,
			"isDeleted": false,
			"id": "7OVlYkCz",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -403.07314724392654,
			"y": -96.19531250000034,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 499.859619140625,
			"height": 25,
			"seed": 687366089,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724103,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "7. Write a rough draft and pare down your outline",
			"rawText": "7. Write a rough draft and pare down your outline",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "_FNB2vcRTwqaikT5aoXvQ",
			"originalText": "7. Write a rough draft and pare down your outline",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 120577127,
			"isDeleted": false,
			"id": "FvsWEqqw",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -242.5054592556453,
			"y": 185.29687499999966,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 178.2398681640625,
			"height": 50,
			"seed": 1414233769,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724103,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "8. Is your draft\nclear and concise?",
			"rawText": "8. Is your draft clear and concise?",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "xFPaJVFoEt9LCEA_lVySl",
			"originalText": "8. Is your draft clear and concise?",
			"lineHeight": 1.25,
			"baseline": 43
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 770029447,
			"isDeleted": false,
			"id": "JQsH4sSS",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -553.1481289333797,
			"y": 524.7734374999997,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 303.91973876953125,
			"height": 25,
			"seed": 697811337,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724103,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "9. Specify your subject matter",
			"rawText": "9. Specify your subject matter",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "A7lz4_X6cv1Jl3UGa8Ur9",
			"originalText": "9. Specify your subject matter",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 863186599,
			"isDeleted": false,
			"id": "G0kgD2Kn",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -132.6982082790828,
			"y": 524.7734374999997,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 455.1995849609375,
			"height": 25,
			"seed": 1444456553,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724103,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "10. Revise your draft and simplify your outline",
			"rawText": "10. Revise your draft and simplify your outline",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "0gqAbQA--ZTQ9ixTshSSl",
			"originalText": "10. Revise your draft and simplify your outline",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 310690247,
			"isDeleted": false,
			"id": "sxO59QMO",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -619.1080593533015,
			"y": 622.2734374999997,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 435.839599609375,
			"height": 25,
			"seed": 1402581833,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724103,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "11. Read aloud until your draft is error-free",
			"rawText": "11. Read aloud until your draft is error-free",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "SFb3-c3W6TlFl9I0LC5lq",
			"originalText": "11. Read aloud until your draft is error-free",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 1010233575,
			"isDeleted": false,
			"id": "X0Z1Ht8I",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -513.4581570095515,
			"y": 719.7734374999997,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 224.539794921875,
			"height": 25,
			"seed": 1450598953,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724103,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "12. Publish your article",
			"rawText": "12. Publish your article",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "j1jCP-Suzj76uDQOENxJK",
			"originalText": "12. Publish your article",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 1242971143,
			"isDeleted": false,
			"id": "mWt8VuUN",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -169.20305434841873,
			"y": -258.69543750000037,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 32.119964599609375,
			"height": 25,
			"seed": 2073703689,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724103,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Yes",
			"rawText": "Yes",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "Rlk-8JbpglvlL1HL_fN-1",
			"originalText": "Yes",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 1881088807,
			"isDeleted": false,
			"id": "FHVE7NRj",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 372.0169398532414,
			"y": -258.69543750000037,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 23.959976196289062,
			"height": 25,
			"seed": 914402281,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724103,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "No",
			"rawText": "No",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "PBQhOj8IeoprQsbe2-5qG",
			"originalText": "No",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 784213575,
			"isDeleted": false,
			"id": "YdhtxsRK",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -417.2480543484187,
			"y": 459.7735624999997,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 32.119964599609375,
			"height": 25,
			"seed": 2134197961,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724103,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Yes",
			"rawText": "Yes",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "GudosHJqhTWmMl8uRI200",
			"originalText": "Yes",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 1154467175,
			"isDeleted": false,
			"id": "9W9EViJw",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 82.92193985324138,
			"y": 459.7735624999997,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 23.959976196289062,
			"height": 25,
			"seed": 1079215529,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778724103,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "No",
			"rawText": "No",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "groz-5B_lAsswaGpW1lsR",
			"originalText": "No",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 117,
			"versionNonce": 1655797191,
			"isDeleted": false,
			"id": "qiCKmJXU",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -310.26388888889255,
			"y": -1096.8750000000018,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 851.044921875,
			"height": 41.4,
			"seed": 1502398921,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706778800744,
			"link": null,
			"locked": false,
			"fontSize": 36,
			"fontFamily": 2,
			"text": "How to Write Effective Articles: A Step-by-Step Guide",
			"rawText": "How to Write Effective Articles: A Step-by-Step Guide",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "How to Write Effective Articles: A Step-by-Step Guide",
			"lineHeight": 1.15,
			"baseline": 33
		},
		{
			"id": "h32tw9sgq-8Qb-zf9eRqa",
			"type": "frame",
			"x": -370.35720486111404,
			"y": -735.1816406250011,
			"width": 455.595703125,
			"height": 267.958984375,
			"angle": 0,
			"strokeColor": "#bbb",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 922758951,
			"version": 17,
			"versionNonce": 1359333289,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1706778904093,
			"link": null,
			"locked": false,
			"customData": {
				"frameColor": {
					"stroke": "#D4D4D4",
					"fill": "#ADADAD",
					"nameColor": "#949494"
				}
			},
			"name": null
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#1e1e1e",
		"currentItemBackgroundColor": "#b2f2bb",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 2,
		"currentItemFontSize": 36,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 944.986111111114,
		"scrollY": 887.5937500000011,
		"zoom": {
			"value": 0.4
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"gridColor": {
			"Bold": "#C9C9C9FF",
			"Regular": "#EDEDEDFF"
		},
		"currentStrokeOptions": null,
		"previousGridSize": null,
		"frameRendering": {
			"enabled": true,
			"clip": true,
			"name": true,
			"outline": true
		}
	},
	"files": {}
}
```
%%