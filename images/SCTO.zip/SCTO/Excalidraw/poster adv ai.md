---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements

# Embedded files
54ce3f2aa3621ae20f40e1c51a626cfe1b4a5696: [[Pasted Image 20240202095039_003.jpg]]

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/2.0.18",
	"elements": [
		{
			"id": "xLLvs60jaPiF-iPg2SuGn",
			"type": "image",
			"x": -178.890625,
			"y": -201.6484375,
			"width": 165.85546875000003,
			"height": 165.85546875000003,
			"angle": 0,
			"strokeColor": "transparent",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"seed": 1939144295,
			"version": 83,
			"versionNonce": 1684552839,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1706838646915,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "54ce3f2aa3621ae20f40e1c51a626cfe1b4a5696",
			"scale": [
				1,
				1
			]
		},
		{
			"type": "rectangle",
			"version": 28,
			"versionNonce": 792338921,
			"isDeleted": true,
			"id": "2WddSnqjoJBNY0gW8ELX-",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -113.2734375,
			"y": -152.55078125,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 166.1484375,
			"height": 87.234375,
			"seed": 964479591,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1706838641773,
			"link": null,
			"locked": false
		},
		{
			"type": "diamond",
			"version": 88,
			"versionNonce": 1834078279,
			"isDeleted": true,
			"id": "Kh_Qqt30dXSIuQtL9G1ra",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -82.57421875,
			"y": -102.10546875,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 110.05078125,
			"height": 124.76171875,
			"seed": 76491049,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706838644817,
			"link": null,
			"locked": false
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#1e1e1e",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 320.57421875,
		"scrollY": 270.380859375,
		"zoom": {
			"value": 2
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"gridColor": {
			"Bold": "#C9C9C9FF",
			"Regular": "#EDEDEDFF"
		},
		"currentStrokeOptions": null,
		"previousGridSize": null,
		"frameRendering": {
			"enabled": true,
			"clip": true,
			"name": true,
			"outline": true
		}
	},
	"files": {}
}
```
%%