---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
API
Gateway ^dOVVvHDG

G ^jCinSI0E

o ^4TFpbv9z

o ^KGDSfsvP

g ^fJiFah4q

l ^t6svU247

e ^95MHh9Kw

Lorem ipsum dolor sit amet, 
consectetur adipiscing elit,sed
 do eiusmod tempor incididunt
 ut labore et dolore magna
 aliqua. Ut enim ad miveniam,
 quis nostrud exercitaullamco 
laboris nisi ut aliquip ex ea 
ommodo consequat. Duis aute 
irure dolor in reprehenderit i ^NljFaxH8

Lorem ipsum dolor s, 
consectetur adipng d
 do eiusmopor incididunt
ut labore et dolore magna
aliqua. Ut enim ad miveniam,
quis nostrud exercitaullamco 
laboris nisi ut aliquip ex ea 
ommodo consequat. Duis aute 
 ^uksEwkCQ

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/2.0.18",
	"elements": [
		{
			"type": "rectangle",
			"version": 504,
			"versionNonce": 790961833,
			"isDeleted": false,
			"id": "6CfblycSLXW5jwTKAKoqh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 60,
			"angle": 0,
			"x": 75.74410641763944,
			"y": -44.188195321947376,
			"strokeColor": "#0b7285",
			"backgroundColor": "#15aabf",
			"width": 213,
			"height": 170,
			"seed": 1258374183,
			"groupIds": [
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 1
			},
			"boundElements": [
				{
					"id": "dOVVvHDG",
					"type": "text"
				},
				{
					"id": "X19jZdhcJjiZnSwQgyUsM",
					"type": "arrow"
				},
				{
					"id": "LA4ZhHN7AxP40q8-KBUl1",
					"type": "arrow"
				},
				{
					"id": "e7EypW0Xf519yRUMbZvfJ",
					"type": "arrow"
				},
				{
					"id": "Q_dPACU0FVl9HOjBTHaoX",
					"type": "arrow"
				}
			],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 360,
			"versionNonce": 980407561,
			"isDeleted": false,
			"id": "dOVVvHDG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 139.11413205240507,
			"y": 15.811804678052624,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 86.25994873046875,
			"height": 50,
			"seed": 179578695,
			"groupIds": [
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "API\nGateway",
			"rawText": "",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "6CfblycSLXW5jwTKAKoqh",
			"originalText": "API\nGateway",
			"lineHeight": 1.25,
			"baseline": 43
		},
		{
			"type": "rectangle",
			"version": 935,
			"versionNonce": 1235373033,
			"isDeleted": false,
			"id": "cXh8oF87gB74aB_WwwnLP",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -255.70677036714238,
			"y": -212.26552157825176,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 127.88383573213892,
			"height": 76.53703389977764,
			"seed": 341681767,
			"groupIds": [
				"ISYj2Po_RXXgRi9dT7YBo",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 721,
			"versionNonce": 2099439305,
			"isDeleted": false,
			"id": "nxWIlRAkupDRkPLw8Ihc6",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -256.7823681180376,
			"y": -201.5489871860076,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 128.84193229844433,
			"height": 0,
			"seed": 650789255,
			"groupIds": [
				"ISYj2Po_RXXgRi9dT7YBo",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					128.84193229844433,
					0
				]
			]
		},
		{
			"type": "ellipse",
			"version": 541,
			"versionNonce": 1871521193,
			"isDeleted": false,
			"id": "wGOqGYIRVF6iRd2SWl7Xv",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -251.2187348981875,
			"y": -207.99395177824294,
			"strokeColor": "#000000",
			"backgroundColor": "#fa5252",
			"width": 5.001953125,
			"height": 5.001953125,
			"seed": 1932949671,
			"groupIds": [
				"ISYj2Po_RXXgRi9dT7YBo",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 586,
			"versionNonce": 1544325257,
			"isDeleted": false,
			"id": "WMFBA3xXrVRh0ZRNZKqMz",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -240.9560395856875,
			"y": -207.99395177824294,
			"strokeColor": "#000000",
			"backgroundColor": "#fab005",
			"width": 5.001953125,
			"height": 5.001953125,
			"seed": 1330564039,
			"groupIds": [
				"ISYj2Po_RXXgRi9dT7YBo",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 644,
			"versionNonce": 207392617,
			"isDeleted": false,
			"id": "h7Iugk-OkF9Bh1JezGCnZ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -230.24262311934132,
			"y": -207.54323062439676,
			"strokeColor": "#000000",
			"backgroundColor": "#40c057",
			"width": 5.001953125,
			"height": 5.001953125,
			"seed": 657439463,
			"groupIds": [
				"ISYj2Po_RXXgRi9dT7YBo",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 923,
			"versionNonce": 113818185,
			"isDeleted": false,
			"id": "dBAUMh18AOOJCey6l69Is",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"angle": 0,
			"x": -214.2155621297141,
			"y": -191.49086174638092,
			"strokeColor": "#000000",
			"backgroundColor": "#04aaf7",
			"width": 42.72020253937572,
			"height": 42.72020253937572,
			"seed": 795198983,
			"groupIds": [
				"ISYj2Po_RXXgRi9dT7YBo",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 1540,
			"versionNonce": 2083293481,
			"isDeleted": false,
			"id": "t5vZhq3b46fzaXhyf3mM9",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -187.1373980677385,
			"y": -175.26650968192342,
			"strokeColor": "#087f5b",
			"backgroundColor": "#40c057",
			"width": 28.226201983883442,
			"height": 24.44112284281997,
			"seed": 1458400551,
			"groupIds": [
				"ISYj2Po_RXXgRi9dT7YBo",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.8305638688608794,
					-0.4146385831511896
				],
				[
					-7.572250391862635,
					-6.271625431345418
				],
				[
					-11.35769254157424,
					-4.347633009945142
				],
				[
					-12.611765400987878,
					2.3733287939365098
				],
				[
					-11.26889653301009,
					6.740045588043412
				],
				[
					-17.42450906516472,
					8.886103861507927
				],
				[
					-17.203202089974113,
					13.643170786196503
				],
				[
					-12.380895778721076,
					13.349974465892952
				],
				[
					-8.695178377089249,
					9.477701170522828
				],
				[
					-3.6201449645383086,
					17.867626643824725
				],
				[
					-0.415292101592283,
					18.169497411474552
				],
				[
					-3.7772455950748833,
					4.800439161419844
				],
				[
					1.3865838260401944,
					4.3476330099451115
				],
				[
					3.162503997323137,
					5.86739618500973
				],
				[
					9.236150983110862,
					5.86739618500973
				],
				[
					10.80169291871872,
					0.6349695457461695
				],
				[
					4.221225637895673,
					1.1103292603211785
				],
				[
					5.486227236824892,
					-5.759833037916143
				],
				[
					2.472627315401658,
					-5.345194454764953
				],
				[
					-0.23770008446403423,
					-0.9229611976419838
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 960,
			"versionNonce": 1978891273,
			"isDeleted": false,
			"id": "V_0eW9PVhTphETXcBzaZ4",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"angle": 0,
			"x": -213.15649965568656,
			"y": -170.52798818319997,
			"strokeColor": "#000000",
			"backgroundColor": "#99bcff",
			"width": 42.095115772272244,
			"height": 0,
			"seed": 2033397831,
			"groupIds": [
				"ISYj2Po_RXXgRi9dT7YBo",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					42.095115772272244,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 3167,
			"versionNonce": 1142493929,
			"isDeleted": false,
			"id": "Cmt2cTxlVWYXPR26v3NlF",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 90,
			"angle": 0,
			"x": -208.0611706259122,
			"y": -185.962517110166,
			"strokeColor": "#000000",
			"backgroundColor": "#99bcff",
			"width": 29.31860660384862,
			"height": 5.711199931375845,
			"seed": 1343459175,
			"groupIds": [
				"ISYj2Po_RXXgRi9dT7YBo",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.7724193963150375,
					2.2765797384357125
				],
				[
					4.103544916365185,
					4.186609221587683
				],
				[
					8.536129150893453,
					5.343311508306209
				],
				[
					15.480325949120388,
					5.448716592152419
				],
				[
					23.583965316012858,
					4.712296432964328
				],
				[
					28.316582284417855,
					2.033216518393959
				],
				[
					29.31860660384862,
					-0.2624833392234258
				]
			]
		},
		{
			"type": "ellipse",
			"version": 984,
			"versionNonce": 724094409,
			"isDeleted": false,
			"id": "gEG80K-6mccKA-Q3B1qch",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 90,
			"angle": 0,
			"x": -199.98725470199275,
			"y": -192.8733913759736,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 15.528434353116108,
			"height": 44.82230388130942,
			"seed": 635112071,
			"groupIds": [
				"ISYj2Po_RXXgRi9dT7YBo",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 3372,
			"versionNonce": 1379806377,
			"isDeleted": false,
			"id": "bpsIvIhgWJteQbfuk7C58",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 90,
			"angle": 0,
			"x": -206.54521911628632,
			"y": -154.22542505172527,
			"strokeColor": "#000000",
			"backgroundColor": "#99bcff",
			"width": 29.31860660384862,
			"height": 5.896061363392446,
			"seed": 1195778471,
			"groupIds": [
				"ISYj2Po_RXXgRi9dT7YBo",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					4.103544916365185,
					-4.322122351104391
				],
				[
					8.536129150893453,
					-5.516265043290966
				],
				[
					15.480325949120388,
					-5.625081903117008
				],
				[
					23.583965316012858,
					-4.8648251269605955
				],
				[
					28.316582284417855,
					-2.0990281379671547
				],
				[
					29.31860660384862,
					0.2709794602754383
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1232,
			"versionNonce": 1896132489,
			"isDeleted": false,
			"id": "g_4smwlw0_p-wJHdNoiTS",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -307.5235079126474,
			"y": -74.14539774874925,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 70.81644178885557,
			"height": 108.30428902193904,
			"seed": 897668295,
			"groupIds": [
				"_0MPwBTQK3XSox0XN1NL3",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1382,
			"versionNonce": 1035458153,
			"isDeleted": false,
			"id": "jtgT2oib_7dWFua9rKD3u",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -299.4158038225558,
			"y": -65.88821639835231,
			"strokeColor": "#000000",
			"backgroundColor": "#fff",
			"width": 55.801163535143246,
			"height": 82.83278895375764,
			"seed": 405349351,
			"groupIds": [
				"_0MPwBTQK3XSox0XN1NL3",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1428,
			"versionNonce": 455287113,
			"isDeleted": false,
			"id": "W7YlfwbAIIHaAw6ypTbDu",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -277.22913405820367,
			"y": 20.4894667242325,
			"strokeColor": "#000000",
			"backgroundColor": "#fff",
			"width": 11.427824006438863,
			"height": 11.427824006438863,
			"seed": 1867124487,
			"groupIds": [
				"_0MPwBTQK3XSox0XN1NL3",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1075,
			"versionNonce": 111284265,
			"isDeleted": false,
			"id": "hmPJ9n3sgYJsvXUF4mz3i",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -291.1361134225853,
			"y": -55.344059722211966,
			"strokeColor": "#000000",
			"backgroundColor": "#fab005",
			"width": 39.2417827352022,
			"height": 19.889460471185775,
			"seed": 90215975,
			"groupIds": [
				"_0MPwBTQK3XSox0XN1NL3",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1117,
			"versionNonce": 1176511241,
			"isDeleted": false,
			"id": "apbLLBBcP6WpDSDbTKAwa",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -291.1361134225853,
			"y": -19.786299677257773,
			"strokeColor": "#000000",
			"backgroundColor": "#fab005",
			"width": 39.2417827352022,
			"height": 19.889460471185775,
			"seed": 559495495,
			"groupIds": [
				"_0MPwBTQK3XSox0XN1NL3",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2890,
			"versionNonce": 1444469225,
			"isDeleted": false,
			"id": "YRRTirQsI9Sqyk9SvRNGl",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -307.86129391763944,
			"y": 93.04617322450667,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 130.441847900043,
			"height": 78.0679753427682,
			"seed": 2022733927,
			"groupIds": [
				"tpjyKzz1gGM2Eyb7Ku7Pn",
				"2o8PDetwwmwNSX_xeeBID",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2135,
			"versionNonce": 395818185,
			"isDeleted": false,
			"id": "olT0GXGxs_oszQQ4t5qO8",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -307.6797186244201,
			"y": 93.0683868953281,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 129.58095857455965,
			"height": 12.717494608113203,
			"seed": 1624429447,
			"groupIds": [
				"tpjyKzz1gGM2Eyb7Ku7Pn",
				"2o8PDetwwmwNSX_xeeBID",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 2296,
			"versionNonce": 1043870633,
			"isDeleted": false,
			"id": "8pjm7Lt2Kb401HiUeMivG",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -303.28348596669736,
			"y": 96.52015670556034,
			"strokeColor": "#000000",
			"backgroundColor": "#fa5252",
			"width": 5.102005308169075,
			"height": 5.102005308169075,
			"seed": 1113377447,
			"groupIds": [
				"tpjyKzz1gGM2Eyb7Ku7Pn",
				"2o8PDetwwmwNSX_xeeBID",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 2340,
			"versionNonce": 2116408969,
			"isDeleted": false,
			"id": "k9Xosr2-JPQsPzONe10ID",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -292.81550982776895,
			"y": 96.52015670556034,
			"strokeColor": "#000000",
			"backgroundColor": "#fab005",
			"width": 5.102005308169075,
			"height": 5.102005308169075,
			"seed": 1239080391,
			"groupIds": [
				"tpjyKzz1gGM2Eyb7Ku7Pn",
				"2o8PDetwwmwNSX_xeeBID",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 2398,
			"versionNonce": 2048662889,
			"isDeleted": false,
			"id": "hfwzpbYxvP5CB1TOQ16tW",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 0,
			"opacity": 100,
			"angle": 0,
			"x": -281.88779692964596,
			"y": 96.97989346477061,
			"strokeColor": "#000000",
			"backgroundColor": "#40c057",
			"width": 5.102005308169075,
			"height": 5.102005308169075,
			"seed": 1516866791,
			"groupIds": [
				"tpjyKzz1gGM2Eyb7Ku7Pn",
				"2o8PDetwwmwNSX_xeeBID",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 657,
			"versionNonce": 1902544969,
			"isDeleted": false,
			"id": "jCinSI0E",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -272.70945465338497,
			"y": 116.40659437689715,
			"strokeColor": "#228be6",
			"backgroundColor": "#ffffff",
			"width": 10.809295654296875,
			"height": 17.812824760471983,
			"seed": 1066752007,
			"groupIds": [
				"tpjyKzz1gGM2Eyb7Ku7Pn",
				"2o8PDetwwmwNSX_xeeBID",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"fontSize": 13.70217289267076,
			"fontFamily": 1,
			"text": "G",
			"rawText": "",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "G",
			"lineHeight": 1.2999999999999996,
			"baseline": 12
		},
		{
			"type": "text",
			"version": 609,
			"versionNonce": 769693481,
			"isDeleted": false,
			"id": "4TFpbv9z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -259.6923904053472,
			"y": 116.40659437689715,
			"strokeColor": "#d9480f",
			"backgroundColor": "#ffffff",
			"width": 7.5897979736328125,
			"height": 17.812824760471983,
			"seed": 526040871,
			"groupIds": [
				"tpjyKzz1gGM2Eyb7Ku7Pn",
				"2o8PDetwwmwNSX_xeeBID",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"fontSize": 13.702172892670754,
			"fontFamily": 1,
			"text": "o",
			"rawText": "",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "o",
			"lineHeight": 1.3000000000000003,
			"baseline": 12
		},
		{
			"type": "text",
			"version": 616,
			"versionNonce": 838191625,
			"isDeleted": false,
			"id": "KGDSfsvP",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -249.41576073584412,
			"y": 116.40659437689715,
			"strokeColor": "#fab005",
			"backgroundColor": "#ffffff",
			"width": 7.5897979736328125,
			"height": 17.812824760471983,
			"seed": 740704839,
			"groupIds": [
				"tpjyKzz1gGM2Eyb7Ku7Pn",
				"2o8PDetwwmwNSX_xeeBID",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"fontSize": 13.702172892670754,
			"fontFamily": 1,
			"text": "o",
			"rawText": "",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "o",
			"lineHeight": 1.3000000000000003,
			"baseline": 12
		},
		{
			"type": "text",
			"version": 623,
			"versionNonce": 648126697,
			"isDeleted": false,
			"id": "fJiFah4q",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -239.82423971097506,
			"y": 116.40659437689715,
			"strokeColor": "#228be6",
			"backgroundColor": "#ffffff",
			"width": 6.8636932373046875,
			"height": 17.812824760471983,
			"seed": 383017319,
			"groupIds": [
				"tpjyKzz1gGM2Eyb7Ku7Pn",
				"2o8PDetwwmwNSX_xeeBID",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"fontSize": 13.702172892670756,
			"fontFamily": 1,
			"text": "g",
			"rawText": "",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "g",
			"lineHeight": 1.3,
			"baseline": 12
		},
		{
			"type": "text",
			"version": 625,
			"versionNonce": 158309321,
			"isDeleted": false,
			"id": "t6svU247",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -231.60293597537276,
			"y": 116.40659437689715,
			"strokeColor": "#5c940d",
			"backgroundColor": "#ffffff",
			"width": 3.60308837890625,
			"height": 17.812824760471983,
			"seed": 1085381767,
			"groupIds": [
				"tpjyKzz1gGM2Eyb7Ku7Pn",
				"2o8PDetwwmwNSX_xeeBID",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"fontSize": 13.702172892670756,
			"fontFamily": 1,
			"text": "l",
			"rawText": "",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "l",
			"lineHeight": 1.3,
			"baseline": 12
		},
		{
			"type": "text",
			"version": 612,
			"versionNonce": 444283561,
			"isDeleted": false,
			"id": "95MHh9Kw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -226.12206681830497,
			"y": 116.40659437689715,
			"strokeColor": "#d9480f",
			"backgroundColor": "#ffffff",
			"width": 7.493896484375,
			"height": 17.812824760471983,
			"seed": 762999719,
			"groupIds": [
				"tpjyKzz1gGM2Eyb7Ku7Pn",
				"2o8PDetwwmwNSX_xeeBID",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"fontSize": 13.702172892670754,
			"fontFamily": 1,
			"text": "e",
			"rawText": "",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "e",
			"lineHeight": 1.3000000000000003,
			"baseline": 12
		},
		{
			"type": "rectangle",
			"version": 545,
			"versionNonce": 175111561,
			"isDeleted": false,
			"id": "nRhDhiAgE8-U2VAhgyyTP",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -285.8026420841582,
			"y": 137.89616886356873,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 83.88774737623947,
			"height": 12.362404876498449,
			"seed": 895182535,
			"groupIds": [
				"tpjyKzz1gGM2Eyb7Ku7Pn",
				"2o8PDetwwmwNSX_xeeBID",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 1
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 581,
			"versionNonce": 1753834601,
			"isDeleted": false,
			"id": "SronzVQudgsje6Z2uCfTL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -212.06972728504383,
			"y": 140.98677008269317,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 4.898891947531319,
			"height": 4.211328165421662,
			"seed": 1995503079,
			"groupIds": [
				"LKHR6fCTWWN3YMBKWdpsj",
				"tpjyKzz1gGM2Eyb7Ku7Pn",
				"2o8PDetwwmwNSX_xeeBID",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 579,
			"versionNonce": 1351806793,
			"isDeleted": false,
			"id": "0vrPO7v-du9SeA3y9QWHV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"angle": 0,
			"x": -207.27736901778684,
			"y": 145.16063104767557,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 2.492418710147513,
			"height": 3.1799824922571727,
			"seed": 155689223,
			"groupIds": [
				"LKHR6fCTWWN3YMBKWdpsj",
				"tpjyKzz1gGM2Eyb7Ku7Pn",
				"2o8PDetwwmwNSX_xeeBID",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.492418710147513,
					3.1799824922571727
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1903,
			"versionNonce": 1491607081,
			"isDeleted": false,
			"id": "PcNGNeRZHgv631_VzoCrj",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 80,
			"angle": 0,
			"x": -211.51469308253155,
			"y": 218.627635379595,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 84.60227931798867,
			"height": 129.38788619865684,
			"seed": 1843128359,
			"groupIds": [
				"e1SKbrnFTsSRy8lb9s9xB",
				"EUEBu-llWuMywXiaSdqE2",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2126,
			"versionNonce": 1081372937,
			"isDeleted": false,
			"id": "u1KTWvM-_ee8GhyLsQnQH",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 80,
			"angle": 0,
			"x": -207.58159192490922,
			"y": 223.16582463007632,
			"strokeColor": "#000000",
			"backgroundColor": "#fff",
			"width": 75.86866432368348,
			"height": 120.70738781243189,
			"seed": 1117408071,
			"groupIds": [
				"e1SKbrnFTsSRy8lb9s9xB",
				"EUEBu-llWuMywXiaSdqE2",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 2140,
			"versionNonce": 1555261417,
			"isDeleted": false,
			"id": "OsXdZCh98MTJNHikwbeme",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 80,
			"angle": 0,
			"x": -171.32809985946216,
			"y": 222.04963926467423,
			"strokeColor": "#000000",
			"backgroundColor": "#fff",
			"width": 5.218983964155919,
			"height": 5.218983964155919,
			"seed": 870271591,
			"groupIds": [
				"e1SKbrnFTsSRy8lb9s9xB",
				"EUEBu-llWuMywXiaSdqE2",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1797,
			"versionNonce": 1202750153,
			"isDeleted": false,
			"id": "EOYlzVyeyt0uE-UdBZX04",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 80,
			"angle": 0,
			"x": -204.01831685852613,
			"y": 231.884342445796,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 68.16682121289108,
			"height": 31.815443659489233,
			"seed": 779576711,
			"groupIds": [
				"e1SKbrnFTsSRy8lb9s9xB",
				"EUEBu-llWuMywXiaSdqE2",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1823,
			"versionNonce": 1309098409,
			"isDeleted": false,
			"id": "i-vL130uof5RDW0kLf_Ls",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 80,
			"angle": 0,
			"x": -199.415973034538,
			"y": 270.33708119746444,
			"strokeColor": "#000000",
			"backgroundColor": "#fab005",
			"width": 23.86926190701229,
			"height": 18.583705165525398,
			"seed": 1369382055,
			"groupIds": [
				"e1SKbrnFTsSRy8lb9s9xB",
				"EUEBu-llWuMywXiaSdqE2",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1872,
			"versionNonce": 484648073,
			"isDeleted": false,
			"id": "leM76_aQd6mgkVCRiBnDT",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 80,
			"angle": 0,
			"x": -161.2341244945622,
			"y": 305.9475819371458,
			"strokeColor": "#000000",
			"backgroundColor": "#fab005",
			"width": 21.568089995018592,
			"height": 15.707240275533275,
			"seed": 553840583,
			"groupIds": [
				"e1SKbrnFTsSRy8lb9s9xB",
				"EUEBu-llWuMywXiaSdqE2",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 818,
			"versionNonce": 805284713,
			"isDeleted": false,
			"id": "NljFaxH8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 80,
			"angle": 0,
			"x": -171.16062670499542,
			"y": 268.65702367020623,
			"strokeColor": "#495057",
			"backgroundColor": "transparent",
			"width": 38.119110107421875,
			"height": 31.06582081191504,
			"seed": 1992253159,
			"groupIds": [
				"e1SKbrnFTsSRy8lb9s9xB",
				"EUEBu-llWuMywXiaSdqE2",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"fontSize": 2.518381124150024,
			"fontFamily": 1,
			"text": "Lorem ipsum dolor sit amet, \nconsectetur adipiscing elit,sed\n do eiusmod tempor incididunt\n ut labore et dolore magna\n aliqua. Ut enim ad miveniam,\n quis nostrud exercitaullamco \nlaboris nisi ut aliquip ex ea \nommodo consequat. Duis aute \nirure dolor in reprehenderit i",
			"rawText": "",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Lorem ipsum dolor sit amet, \nconsectetur adipiscing elit,sed\n do eiusmod tempor incididunt\n ut labore et dolore magna\n aliqua. Ut enim ad miveniam,\n quis nostrud exercitaullamco \nlaboris nisi ut aliquip ex ea \nommodo consequat. Duis aute \nirure dolor in reprehenderit i",
			"lineHeight": 1.3706256908018875,
			"baseline": 30
		},
		{
			"type": "text",
			"version": 861,
			"versionNonce": 2141738569,
			"isDeleted": false,
			"id": "uksEwkCQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 80,
			"angle": 0,
			"x": -202.5140940059103,
			"y": 293.9535943339668,
			"strokeColor": "#495057",
			"backgroundColor": "transparent",
			"width": 38.119110107421875,
			"height": 31.06582081191504,
			"seed": 895543815,
			"groupIds": [
				"e1SKbrnFTsSRy8lb9s9xB",
				"EUEBu-llWuMywXiaSdqE2",
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706829155159,
			"link": null,
			"locked": false,
			"fontSize": 2.518381124150024,
			"fontFamily": 1,
			"text": "Lorem ipsum dolor s, \nconsectetur adipng d\n do eiusmopor incididunt\nut labore et dolore magna\naliqua. Ut enim ad miveniam,\nquis nostrud exercitaullamco \nlaboris nisi ut aliquip ex ea \nommodo consequat. Duis aute \n",
			"rawText": "",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Lorem ipsum dolor s, \nconsectetur adipng d\n do eiusmopor incididunt\nut labore et dolore magna\naliqua. Ut enim ad miveniam,\nquis nostrud exercitaullamco \nlaboris nisi ut aliquip ex ea \nommodo consequat. Duis aute \n",
			"lineHeight": 1.3706256908018875,
			"baseline": 30
		},
		{
			"type": "arrow",
			"version": 465,
			"versionNonce": 1902686823,
			"isDeleted": false,
			"id": "X19jZdhcJjiZnSwQgyUsM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 50,
			"angle": 0,
			"x": -103.95348275237251,
			"y": -133.86135101066384,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 149.48019251850815,
			"height": 118.2317251677494,
			"seed": 971247911,
			"groupIds": [
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155171,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "6CfblycSLXW5jwTKAKoqh",
				"focus": -0.30546335664496105,
				"gap": 30.217396651503805
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					149.48019251850815,
					118.2317251677494
				]
			]
		},
		{
			"type": "arrow",
			"version": 851,
			"versionNonce": 1184091527,
			"isDeleted": false,
			"id": "e7EypW0Xf519yRUMbZvfJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 50,
			"angle": 0,
			"x": -211.9323188447005,
			"y": -19.212115128801827,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 259.0088459575529,
			"height": 57.36493516884394,
			"seed": 229987399,
			"groupIds": [
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155171,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "6CfblycSLXW5jwTKAKoqh",
				"focus": -0.25120531072511926,
				"gap": 28.66757930478701
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					259.0088459575529,
					57.36493516884394
				]
			]
		},
		{
			"type": "arrow",
			"version": 1105,
			"versionNonce": 2045674663,
			"isDeleted": false,
			"id": "Q_dPACU0FVl9HOjBTHaoX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 50,
			"angle": 0,
			"x": -155.88797235155215,
			"y": 133.65044027057013,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 201.4522947833282,
			"height": 50.00623585225401,
			"seed": 1488008039,
			"groupIds": [
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155171,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "6CfblycSLXW5jwTKAKoqh",
				"focus": -0.07990712195076878,
				"gap": 30.179783985863395
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					201.4522947833282,
					-50.00623585225401
				]
			]
		},
		{
			"type": "arrow",
			"version": 1391,
			"versionNonce": 1529173959,
			"isDeleted": false,
			"id": "LA4ZhHN7AxP40q8-KBUl1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 50,
			"angle": 0,
			"x": -99.04577553587268,
			"y": 278.14020594803065,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 147.74021275898622,
			"height": 157.23725026994006,
			"seed": 321138311,
			"groupIds": [
				"Ow1xek-Jiq0pSqZSt9nFh"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706829155171,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "6CfblycSLXW5jwTKAKoqh",
				"focus": 0.3128036284590252,
				"gap": 27.049669194525904
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					147.74021275898622,
					-157.23725026994006
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#1e1e1e",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 596.75,
		"scrollY": 342.8671875,
		"zoom": {
			"value": 1
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"gridColor": {
			"Bold": "#C9C9C9FF",
			"Regular": "#EDEDEDFF"
		},
		"currentStrokeOptions": null,
		"previousGridSize": null,
		"frameRendering": {
			"enabled": true,
			"clip": true,
			"name": true,
			"outline": true
		}
	},
	"files": {}
}
```
%%