---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Animal ^W4ab9B7s

+int age ^5T61ZAUP

+String gender ^LseQlcZ9

+isMammal() ^54opGqxq

+mate() ^BjDb43nv

Duck ^y8zQxnpI

+String beakColor ^sgXVPHmr

+swim() ^hlCVucJy

+quack() ^uglSZ8CD

Fish ^yT5mN3Eg

-int sizeInFeet ^x0S4LGjr

-canEat() ^VM2jWvkb

Zebra ^rTFmtRdR

+bool is_wild ^6Ru63OEi

+run() ^jpzbxiV5

From Duck till Zebra ^nidr8B9p

can fly\ncan swim\ncan dive\ncan help in debugging ^fVDFsSau

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/2.0.18",
	"elements": [
		{
			"type": "rectangle",
			"version": 6,
			"versionNonce": 1399246119,
			"isDeleted": false,
			"id": "D6FcsvUxcogrkg0HXNady",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 162.7548828125,
			"y": -224.25,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 177.7578125,
			"height": 217.5,
			"seed": 1453810153,
			"groupIds": [
				"El6lLibq2GM-Td0SJfrfM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "dcziDLxXDLsfyiPHIEdHW",
					"type": "arrow"
				},
				{
					"id": "8z0KdLSumD6wILUK5l00_",
					"type": "arrow"
				},
				{
					"id": "IGKN7wRcQvy8VuDwwYF-i",
					"type": "arrow"
				}
			],
			"updated": 1706847094458,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 5,
			"versionNonce": 1602261063,
			"isDeleted": false,
			"id": "CgeOh-pTYheOBKkKuqTQV",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -418.0732421875,
			"y": 43.25,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 212.8203125,
			"height": 181,
			"seed": 353713353,
			"groupIds": [
				"FmRtolg97YCTDaEhhUzHM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "dcziDLxXDLsfyiPHIEdHW",
					"type": "arrow"
				},
				{
					"id": "hmIhHKEMbSAopFuwMuNao",
					"type": "arrow"
				}
			],
			"updated": 1706847094458,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 4,
			"versionNonce": 1169485671,
			"isDeleted": false,
			"id": "4goGeO7lYb5NqXAOaJqsw",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 54.2763671875,
			"y": 61.5,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 176.0859375,
			"height": 144.5,
			"seed": 1120189353,
			"groupIds": [
				"Wxusa4mbIQpCvpkUGb42d"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "8z0KdLSumD6wILUK5l00_",
					"type": "arrow"
				}
			],
			"updated": 1706847094458,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 4,
			"versionNonce": 542141063,
			"isDeleted": false,
			"id": "aoRTC7koOPcH63XqHjhrY",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 280.3623046875,
			"y": 61.5,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 161.171875,
			"height": 144.5,
			"seed": 1340169865,
			"groupIds": [
				"K2PEQz5LXf2-tPQEvWsUA"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "IGKN7wRcQvy8VuDwwYF-i",
					"type": "arrow"
				}
			],
			"updated": 1706847094458,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 3,
			"versionNonce": 202342823,
			"isDeleted": false,
			"id": "Hh2G6hpkcPIv62FKiybTf",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -131.7919921875,
			"y": -139.25,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 244.546875,
			"height": 47.5,
			"seed": 455517545,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "nidr8B9p"
				}
			],
			"updated": 1706847094458,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 4,
			"versionNonce": 1511961799,
			"isDeleted": false,
			"id": "lYa_wj_W276Xn6SZB1bQ0",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -441.5341796875,
			"y": -188,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 259.7421875,
			"height": 145,
			"seed": 534777929,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "fVDFsSau"
				},
				{
					"id": "hmIhHKEMbSAopFuwMuNao",
					"type": "arrow"
				}
			],
			"updated": 1706847094458,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 3,
			"versionNonce": 35292135,
			"isDeleted": false,
			"id": "RHm96GqH1ss2jw9P_E70w",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 162.7548828125,
			"y": -179.75,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 177.7578125,
			"height": 0,
			"seed": 1676222249,
			"groupIds": [
				"El6lLibq2GM-Td0SJfrfM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					177.7578125,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 3,
			"versionNonce": 1410297607,
			"isDeleted": false,
			"id": "ychdePDwh2hUFK4v2fi2s",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 162.7548828125,
			"y": -90.75,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 177.7578125,
			"height": 0,
			"seed": 632115721,
			"groupIds": [
				"El6lLibq2GM-Td0SJfrfM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					177.7578125,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 3,
			"versionNonce": 1786377767,
			"isDeleted": false,
			"id": "NAAuqhO-eqgg8m4D2wFxy",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -418.0732421875,
			"y": 87.75,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 212.8203125,
			"height": 0,
			"seed": 1244145897,
			"groupIds": [
				"FmRtolg97YCTDaEhhUzHM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					212.8203125,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 3,
			"versionNonce": 1548130631,
			"isDeleted": false,
			"id": "dVjBpwV-XNknp_jI_sdHk",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -418.0732421875,
			"y": 140.25,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 212.8203125,
			"height": 0,
			"seed": 182789065,
			"groupIds": [
				"FmRtolg97YCTDaEhhUzHM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					212.8203125,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 3,
			"versionNonce": 785504359,
			"isDeleted": false,
			"id": "y5QSVXFh28I1sp-p87O1u",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 54.2763671875,
			"y": 106,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 176.0859375,
			"height": 0,
			"seed": 1677705897,
			"groupIds": [
				"Wxusa4mbIQpCvpkUGb42d"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					176.0859375,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 3,
			"versionNonce": 132658055,
			"isDeleted": false,
			"id": "1XsYeeCd_aVgiLQEaiNVN",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 54.2763671875,
			"y": 158.5,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 176.0859375,
			"height": 0,
			"seed": 1109624201,
			"groupIds": [
				"Wxusa4mbIQpCvpkUGb42d"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					176.0859375,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 3,
			"versionNonce": 533080743,
			"isDeleted": false,
			"id": "a_RN04mV5HlGpfevZvAub",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 280.3623046875,
			"y": 106,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 161.171875,
			"height": 0,
			"seed": 1888218217,
			"groupIds": [
				"K2PEQz5LXf2-tPQEvWsUA"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					161.171875,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 3,
			"versionNonce": 1930968519,
			"isDeleted": false,
			"id": "5UmRwSr06yNTWXDoRZoOV",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 280.3623046875,
			"y": 158.5,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 161.171875,
			"height": 0,
			"seed": 1191475017,
			"groupIds": [
				"K2PEQz5LXf2-tPQEvWsUA"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					161.171875,
					0
				]
			]
		},
		{
			"type": "arrow",
			"version": 5,
			"versionNonce": 888859879,
			"isDeleted": false,
			"id": "dcziDLxXDLsfyiPHIEdHW",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 145.9948203125,
			"y": -65.071,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 351.748,
			"height": 155.684,
			"seed": 401122857,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "D6FcsvUxcogrkg0HXNady",
				"focus": -0.022921470962619317,
				"gap": 16.260062500000004
			},
			"endBinding": {
				"elementId": "CgeOh-pTYheOBKkKuqTQV",
				"focus": 0.025146768907530467,
				"gap": 1
			},
			"lastCommittedPoint": null,
			"startArrowhead": "triangle_outline",
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-350.748,
					154.684
				]
			]
		},
		{
			"type": "arrow",
			"version": 5,
			"versionNonce": 16431111,
			"isDeleted": false,
			"id": "8z0KdLSumD6wILUK5l00_",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 150.86382031250002,
			"y": 7.6839999999999975,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 9.043999999999983,
			"height": 54.316,
			"seed": 1579415817,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "D6FcsvUxcogrkg0HXNady",
				"focus": 0.7462826667217918,
				"gap": 13.933999999999997
			},
			"endBinding": {
				"elementId": "4goGeO7lYb5NqXAOaJqsw",
				"focus": -0.12020865955670872,
				"gap": 1
			},
			"lastCommittedPoint": null,
			"startArrowhead": "triangle_outline",
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-8.043999999999983,
					53.316
				]
			]
		},
		{
			"type": "arrow",
			"version": 5,
			"versionNonce": 1293164327,
			"isDeleted": false,
			"id": "IGKN7wRcQvy8VuDwwYF-i",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 352.4038203125,
			"y": 7.6839999999999975,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 9.043999999999983,
			"height": 54.316,
			"seed": 724692969,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "D6FcsvUxcogrkg0HXNady",
				"focus": -0.7462832509073517,
				"gap": 13.933999999999997
			},
			"endBinding": {
				"elementId": "aoRTC7koOPcH63XqHjhrY",
				"focus": 0.1298879967738017,
				"gap": 1
			},
			"lastCommittedPoint": null,
			"startArrowhead": "triangle_outline",
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					8.043999999999983,
					53.316
				]
			]
		},
		{
			"type": "arrow",
			"version": 7,
			"versionNonce": 753850567,
			"isDeleted": false,
			"id": "hmIhHKEMbSAopFuwMuNao",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "dotted",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -311.6630859375,
			"y": -42,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 84.25,
			"seed": 1428032201,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706847102505,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "lYa_wj_W276Xn6SZB1bQ0",
				"gap": 1,
				"focus": 0
			},
			"endBinding": {
				"elementId": "CgeOh-pTYheOBKkKuqTQV",
				"gap": 1,
				"focus": 0
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					84.25
				]
			]
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 1840628071,
			"isDeleted": false,
			"id": "W4ab9B7s",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 211.5205078125,
			"y": -219.25,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 58.09996032714844,
			"height": 25,
			"seed": 1686358441,
			"groupIds": [
				"El6lLibq2GM-Td0SJfrfM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Animal",
			"rawText": "Animal",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "Animal",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 1952906375,
			"isDeleted": false,
			"id": "5T61ZAUP",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 170.2548828125,
			"y": -170.75,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 81.8199462890625,
			"height": 25,
			"seed": 1116646537,
			"groupIds": [
				"El6lLibq2GM-Td0SJfrfM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+int age",
			"rawText": "+int age",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "+int age",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 58971047,
			"isDeleted": false,
			"id": "LseQlcZ9",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 170.2548828125,
			"y": -134.25,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 139.51988220214844,
			"height": 25,
			"seed": 653931369,
			"groupIds": [
				"El6lLibq2GM-Td0SJfrfM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+String gender",
			"rawText": "+String gender",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "+String gender",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 1127794375,
			"isDeleted": false,
			"id": "54opGqxq",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 170.2548828125,
			"y": -85.75,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 115.37991333007812,
			"height": 25,
			"seed": 1175576137,
			"groupIds": [
				"El6lLibq2GM-Td0SJfrfM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+isMammal()",
			"rawText": "+isMammal()",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "+isMammal()",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 572675559,
			"isDeleted": false,
			"id": "BjDb43nv",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 170.2548828125,
			"y": -49.25,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 75.79994201660156,
			"height": 25,
			"seed": 1051798825,
			"groupIds": [
				"El6lLibq2GM-Td0SJfrfM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+mate()",
			"rawText": "+mate()",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "+mate()",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 122487047,
			"isDeleted": false,
			"id": "y8zQxnpI",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -340.3271484375,
			"y": 48.25,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 46.739959716796875,
			"height": 25,
			"seed": 1212391433,
			"groupIds": [
				"FmRtolg97YCTDaEhhUzHM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Duck",
			"rawText": "Duck",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "Duck",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 1144342567,
			"isDeleted": false,
			"id": "sgXVPHmr",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -410.5732421875,
			"y": 96.75,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 171.37985229492188,
			"height": 25,
			"seed": 549762793,
			"groupIds": [
				"FmRtolg97YCTDaEhhUzHM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+String beakColor",
			"rawText": "+String beakColor",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "+String beakColor",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 1187490631,
			"isDeleted": false,
			"id": "hlCVucJy",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -410.5732421875,
			"y": 145.25,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 67.63993835449219,
			"height": 25,
			"seed": 985657801,
			"groupIds": [
				"FmRtolg97YCTDaEhhUzHM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+swim()",
			"rawText": "+swim()",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "+swim()",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 190884455,
			"isDeleted": false,
			"id": "uglSZ8CD",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -410.5732421875,
			"y": 181.75,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 82.95994567871094,
			"height": 25,
			"seed": 726716585,
			"groupIds": [
				"FmRtolg97YCTDaEhhUzHM"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+quack()",
			"rawText": "+quack()",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "+quack()",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 1322042759,
			"isDeleted": false,
			"id": "yT5mN3Eg",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 118.5029296875,
			"y": 66.5,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 36.59996032714844,
			"height": 25,
			"seed": 1478677385,
			"groupIds": [
				"Wxusa4mbIQpCvpkUGb42d"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Fish",
			"rawText": "Fish",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "Fish",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 4750503,
			"isDeleted": false,
			"id": "x0S4LGjr",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 61.7763671875,
			"y": 115,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 145.75985717773438,
			"height": 25,
			"seed": 1701935721,
			"groupIds": [
				"Wxusa4mbIQpCvpkUGb42d"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "-int sizeInFeet",
			"rawText": "-int sizeInFeet",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "-int sizeInFeet",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 1937788871,
			"isDeleted": false,
			"id": "VM2jWvkb",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 61.7763671875,
			"y": 163.5,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 94.11993408203125,
			"height": 25,
			"seed": 1678263625,
			"groupIds": [
				"Wxusa4mbIQpCvpkUGb42d"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "-canEat()",
			"rawText": "-canEat()",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "-canEat()",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 1385217767,
			"isDeleted": false,
			"id": "rTFmtRdR",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 327.8818359375,
			"y": 66.5,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 58.979949951171875,
			"height": 25,
			"seed": 1061336105,
			"groupIds": [
				"K2PEQz5LXf2-tPQEvWsUA"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Zebra",
			"rawText": "Zebra",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "Zebra",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 1342589447,
			"isDeleted": false,
			"id": "6Ru63OEi",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 287.8623046875,
			"y": 115,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 125.03988647460938,
			"height": 25,
			"seed": 1795966729,
			"groupIds": [
				"K2PEQz5LXf2-tPQEvWsUA"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+bool is_wild",
			"rawText": "+bool is_wild",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "+bool is_wild",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 3,
			"versionNonce": 417165607,
			"isDeleted": false,
			"id": "jpzbxiV5",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 287.8623046875,
			"y": 163.5,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 56.859954833984375,
			"height": 25,
			"seed": 1373666793,
			"groupIds": [
				"K2PEQz5LXf2-tPQEvWsUA"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "+run()",
			"rawText": "+run()",
			"textAlign": "left",
			"verticalAlign": "middle",
			"containerId": null,
			"originalText": "+run()",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 109229127,
			"isDeleted": false,
			"id": "nidr8B9p",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -91.81450653076172,
			"y": -125.5,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 164.59190368652344,
			"height": 20,
			"seed": 46848201,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "From Duck till Zebra",
			"rawText": "From Duck till Zebra",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "Hh2G6hpkcPIv62FKiybTf",
			"originalText": "From Duck till Zebra",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "text",
			"version": 4,
			"versionNonce": 282235751,
			"isDeleted": false,
			"id": "fVDFsSau",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -414.2630310058594,
			"y": -135.5,
			"strokeColor": "#000",
			"backgroundColor": "transparent",
			"width": 205.19989013671875,
			"height": 40,
			"seed": 526833577,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1706847094458,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "can fly\\ncan swim\\ncan\ndive\\ncan help in debugging",
			"rawText": "can fly\\ncan swim\\ncan dive\\ncan help in debugging",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "lYa_wj_W276Xn6SZB1bQ0",
			"originalText": "can fly\\ncan swim\\ncan dive\\ncan help in debugging",
			"lineHeight": 1.25,
			"baseline": 34
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#1e1e1e",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 580.75,
		"scrollY": 410.8671875,
		"zoom": {
			"value": 1
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"gridColor": {
			"Bold": "#C9C9C9FF",
			"Regular": "#EDEDEDFF"
		},
		"currentStrokeOptions": null,
		"previousGridSize": null,
		"frameRendering": {
			"enabled": true,
			"clip": true,
			"name": true,
			"outline": true
		}
	},
	"files": {}
}
```
%%