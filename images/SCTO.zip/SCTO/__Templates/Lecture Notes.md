Year: [[Freshman]] 
Subject: [[]] 
Date: {{date}} 
Lecture {{title}} 
## Main Points
-
## Related Books
-
## Things to Memorize
-