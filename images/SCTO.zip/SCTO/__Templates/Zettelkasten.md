
{{date}} 
## Tags: 
# {{title}} 
-
## Related Ideas [[]] 
## Source [[]]
-