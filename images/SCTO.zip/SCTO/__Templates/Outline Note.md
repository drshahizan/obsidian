


## References

```dataview
TABLE DOI FROM outgoing([[]]) AND "1️⃣ Primary Sources"
```
