{{title}} Questionnaire 

Please answer the following questions about {{title}} 

What do you think about {{title}} ? 
-

Would you buy {{title}} if it were availble in stores? 
-

How much would you pay for a product like {{title}} ? 
-