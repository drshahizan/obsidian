# Systematic Literature Review (SLR) Using AI
| Session | Topic | Date |
| :--: | ---- | ---- |
| 1a | [AI Tools for Literature Review](https://github.com/drshahizan/SLR-FC/blob/main/materials/session1a.md) | 23 and 24 Jan 2024 |
| 1b | [Advanced AI Tools for Literature Review Course](https://github.com/drshahizan/SLR-FC/blob/main/materials/session1b.md) | 4 and 5 Feb 2024 |
| 2 | SLR Mastery: From Theory to Practice | X Feb 2024 |
| 3 | Mastering the Art of Crafting a SLR | X Feb 2023 |
| 4 | Mentoring Session | X Mac 2024 |

## Example
[[Session 1]]
[[Session 2]]
[[Session 3]]

