# Session 3


- **Topic:** Mastering the Art of Crafting a SLR 
- **Date:** X Feb 2023

![[how to write]]
