# Session 1

- **Topic:** [AI Tools for Literature Review](https://github.com/drshahizan/SLR-FC/blob/main/materials/session1a.md) 
- **Date:** 23 and 24 Jan 2024

[[Introduction SLR and AI]]


![[SLR github|800]]
![[poster adv ai]]