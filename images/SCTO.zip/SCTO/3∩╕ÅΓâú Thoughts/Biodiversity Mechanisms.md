
> [!NOTE] Explanation
> This is an example Thoughts note on the idea of biodiversity. Here I write down questions and ideas as they come along - they are the seeds to create an ontology. For example the question posed here could become an ontology titled "The development of the concept of biodiversity since the 60s" and more or less answer it. 
> 
> The more you write down here, the more "critical" your thinking becomes. It is a good exercise in creativity to jot down ideas as soon as they come.  

# Questions 

In [[Pianka 1966]] 6 different hypothesis (time, spatial, competition, predation, climate and productivity) are analysed regarding biodiversity. But this was back in 1966 - what happened in the meantime? 


# Ideas

While biodiversity is measured using the [[Diversity#^6a8f55|Shanon Index]] this only applies to measuring the abundance of individuals. But could we instead measure genetic diversity? The definition of a species is anyway not very clear in biology. 

