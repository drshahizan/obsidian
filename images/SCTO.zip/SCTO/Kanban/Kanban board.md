---

kanban-plugin: basic

---

## Todo

- [ ] [[IoT blockchain]]


## Backlog

- [ ] [[Mind mapping]]


## Bugs and issues

- [ ] [[Zotero]]


## Done

**Complete**
- [ ] [[Connell 1964]]
- [ ] [[24 Dec 2022]]
- [ ] [[📚 Reading List]]


***

## Archive

- [x] ![[Connell 1964.pdf]] ✅ 2024-02-03
- [x] abc ✅ 2024-02-03

%% kanban:settings
```
{"kanban-plugin":"basic"}
```
%%